import numpy as np
from scipy.spatial.transform import Rotation as R

    # see paragraph above Eq.13
    # of Chaumette, Francois, and Seth Hutchinson. "Visual servo control. I. Basic approaches."
    # https://hal.inria.fr/inria-00350283/document

def calculate_error(p_cur,R_cur,p_target,R_target,translation_only=False):
    t_del=(p_cur-p_target)
    theta,u=u_theta(R_cur,R_target)  #Computes a skew-symmetric matrix that represents the rotation error
    if translation_only:
        error = np.hstack((t_del, np.zeros(3)))
    else:
    # Make the rotation error a 3D vector
    #R_err_vec = modern_robotics.so3ToVec(R_err)
        error = np.hstack((t_del, theta*u))
    return error

def u_theta(R_curr,target_feature_R):
    rotation_error_matrix=np.matmul(target_feature_R,np.transpose(R_curr))
    s=R.from_matrix(rotation_error_matrix) #s is a rotation matrix
    s=s.as_rotvec()
    theta=np.linalg.norm(s) #theta is the rotation angle in rad
    if theta==0:
        translation_only=Trueu=np.zeros(3)
    else:
        u=np.divide(s,theta+(10**(-5))) #u is the direction oof the rotation
    return u,theta
        

def skew_sym_matrix(i):
    sym_matrix=np.array([[0,-i[2],i[1]],[i[2],0,-i[0]],[-i[1],i[0],0]])
    return sym_matrix

def feature_jacobian(t_curr, R_curr, target_feature_R):
    '''
    form interaction matrix / feature jacobian base on current camera pose
    Input:  (object in current camera frame)
            t_input, 1x3 vector
            R_input, 3x3 matrix
    Output: Interation Matrix (feature Jacobian), 6x6
    '''
    
    J_left=np.vstack((-np.identity(3),np.zeros((3,3))))
    u,theta=u_theta(R_curr,target_feature_R)
    S_u=skew_sym_matrix(u)
    S_t_curr=skew_sym_matrix(t_curr)
    J_theta_u=np.identity(3)-theta/2*S_u+(1-np.sinc(theta)/(np.sinc(theta/2)**2))*S_u**2
    J_right=np.vstack((S_t_curr,J_theta_u))
    L_out=np.hstack((J_left,J_right))
    
    return L_out

def control(J_gripper, error, _lambda):
    '''
    calculate the twist of camera frame required to reach target pose
    Input:  (object in current camera frame)
            t_input, 1x3 vector
            R_input, 3x3 matrix
    Output: Twist in camera frame
            [nu_c, omg_c], 1x6
    '''
    vel=-_lambda*np.dot(np.linalg.inv(J_gripper),error)

    return vel.transpose()


