import numpy as np
import pickle
import os
import glob
import matplotlib.pyplot as plt
import Morten_Robotics as MR


locy = r'C:\Users\Morten\OneDrive - mail.tau.ac.il\לימודים משותפים\מעבדות\שנה ד\סמסטר ב\מעבדה ברובוטיקה ובקרה של מערכות\מעבדה 5 - בקרה'

data_path = os.path.join(locy, 'data')
MR.create_directory(locy+'//Plots')
'''
data is a list, every element is a route.
each route is a list of 3 elements first element velocity, second element is error of each joint, third matrix desrcibe location
'''
lambda_val=[0.4,0.5,0.6,0.7,0.8]
data = []
for file in glob.glob(data_path + '/*/*.pkl'):
    with open(file, 'rb') as h:
        data.append(pickle.load(h))


#plot RMSE
for ind, section in enumerate(data):
    joints = MR.colum_extractor(section[1])

    # Start Plotiing
    fig = plt.figure(figsize=(12,9))
    ax = fig.add_subplot()
    
    x_axis_for_plot = np.linspace(1, len(joints[0]), len(joints[0]))
    
    ax.plot(x_axis_for_plot, joints[0], label = 'Joint 1')
    ax.plot(x_axis_for_plot, joints[1], label = 'Joint 2')
    ax.plot(x_axis_for_plot, joints[2], label = 'Joint 3')
    ax.plot(x_axis_for_plot, joints[3], label = 'Joint 4')
    ax.plot(x_axis_for_plot, joints[4], label = 'Joint 5')
    ax.plot(x_axis_for_plot, joints[5], label = 'Joint 6')

    ax.set_xlabel('Iteration', fontsize = 12)
    ax.set_ylabel('Error [°]', fontsize = 12)
    ax.legend(bbox_to_anchor = (0.5, -0.07), loc='upper center', fancybox=True, framealpha = 0, ncol = 6, prop = {'size': 12})
    # ax.set_title(r'$\theta$'+' vs Time '+ number_to_place(ind+1) + ' Route', fontsize = 16)

 
    #title and other shit
    ax.set_title( r'$\ \lambda$'+"="+str(lambda_val[ind]), fontsize = 16)
    plt.savefig(locy+'//Plots//LAB 5 lambda ' +str(ind+1)+'.svg', bbox_inches='tight', transparent=True)
    if True:
        plt.show()
    plt.close()