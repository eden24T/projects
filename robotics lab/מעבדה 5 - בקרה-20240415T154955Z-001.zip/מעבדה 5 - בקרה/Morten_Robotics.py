import numpy as np
import os
from sympy import *
from scipy.spatial.transform import Rotation


alpha1, alpha2, alpha3, alpha4, alpha5, alpha6 = symbols('alpha1:7')
a1, a2, a3, a4, a5, a6 = symbols('a1:7')
d1, d2, d3, d4, d5, d6 = symbols('d1:7')
q1, q2, q3, q4, q5, q6 = symbols('q1:7')
theta_1,theta_2,theta_3,theta_4,theta_5,theta_6=symbols('theta1:7')

theta_list=[theta_1,theta_2,theta_3,theta_4,theta_5,theta_6]

def set_dh_table():
    """
    DH table
    Returns: dh dict
    Important: all length arguments in [m]
               all angles argument in [radians]
    """

    dh_subs_dict = {alpha1: pi / 2,    a1: 0,     d1: 0.1283 + 0.115,    q1: q1,
                    alpha2: pi,        a2: 0.28,  d2: 0.030,             q2: q2 + pi / 2,
                    alpha3: pi / 2,    a3: 0,     d3: 0.020,             q3: q3 + pi / 2,
                    alpha4: pi / 2,    a4: 0,     d4: 0.140 + 0.105,     q4: q4 + pi / 2,
                    alpha5: pi / 2,    a5: 0,     d5: 0.0285 + 0.0285,   q5: q5 + pi,
                    alpha6: 0,         a6: 0,     d6: 0.1050 + 0.130,    q6: q6 + pi / 2}

    return dh_subs_dict


def dh(alpha, a, d, theta):
    """
    Args:
        alpha: torsion angle
        a: distance
        d: translation
        theta: rotation angle

    Returns: Homogeneous DH matrix

    Important note: use sympy cos/sin arguments instead of math/numpy versions.
    i.e: cos(theta) \ sin(theta)

    """
    DH = Matrix([[cos(theta), -sin(theta) * cos(alpha), sin(theta) * sin(alpha), a * cos(theta)],
                 [sin(theta), cos(theta) * cos(alpha), -cos(theta) * sin(alpha), a * sin(theta)],
                 [0, sin(alpha), cos(alpha), d], [0, 0, 0, 1]])
    return DH


def FK(theta_list):
    """
    Args:
        theta_list: joint angle vector ---> list [1,6]
    Returns:
        End effector homogeneous matrix --> Matrix((4, 4))

    Hints:
        - we have added a sympy implementation with missing parts, u dont have to use the same method.
        - chain 'Tes' to T_06 at the end.
    """
    table = set_dh_table()

    T_01 = dh(table[alpha1], table[a1], table[d1], table[q1])
    T_12 = dh(table[alpha2], table[a2], table[d2], table[q2])
    T_23 = dh(table[alpha3], table[a3], table[d3], table[q3])
    T_34 = dh(table[alpha4], table[a4], table[d4], table[q4])
    T_45 = dh(table[alpha5], table[a5], table[d5], table[q5])
    T_56 = dh(table[alpha6], table[a6], table[d6], table[q6])
    Tes = Matrix([[0, -1, 0, 0], [1, 0, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])  # mandatory
    T = T_01 * T_12 * T_23 * T_34 * T_45 * T_56 * Tes

    ''' fill angles to dict for sympy calculations'''

    theta_dict = {}
    keys = [q1, q2, q3, q4, q5, q6]
    for i in range(len(theta_list)):
        theta_dict[keys[i]] = theta_list[i]
    ''' 
    homogeneous transformation matrix from base_link to end_effector [type: numeric matrix] 
    because we are using sympy, we have to use evalf.
    '''
    T_0G_eval = T.evalf(subs=theta_dict, chop=True, maxn=4)

    return T_0G_eval


def xyz_eulerm(A):
    """
    Extract translation and orientation in euler angles

    Args:
        A: Homogeneous transformation --> np.array((4, 4))

    Returns: x, y, z, thetax, thetay, thetaz --> np.array((1, 6))

    Important note: use numpy arrays

    """
    M = np.copy(A)
    M = M[:, -1]
    M = M[:-1]

    R = Rotation.from_matrix(A[:3, :3])
    M2 = R.as_euler('xyz', degrees=True)

    yaw = [np.array(M2[2]).astype(np.float64)]
    roll = [np.array(M2[0]).astype(np.float64)]
    pitch = [np.array(M2[1]).astype(np.float64)]

    arrayte = np.append(M, roll)
    arrayte = np.append(arrayte, pitch)
    arrayte = np.append(arrayte, yaw)

    return np.array([M, roll, pitch, yaw])

def xyz_euler_mat(A):

    """
    Extract translation and orientation in euler angles

    Args:
        A: Homogeneous transformation --> np.array((4, 4))

    Returns: x, y, z, roll, pitch, yaw --> np.array((1, 6))
             x, y, z --> [m]
             roll, pitch, yaw -- > [degrees]

    Important note: use numpy arrays

    """
    x = [np.array(A[0, -1]).astype(np.float64)]
    y = [np.array(A[1, -1]).astype(np.float64)]
    z = [np.array(A[2, -1]).astype(np.float64)]
    R = Rotation.from_matrix(A[:3, :3])
    # Euler = R.as_rotvec(degrees=True)
    Euler = R.as_euler('xyz', degrees=True)

    roll = [np.array(Euler[0]).astype(np.float64)]
    pitch = [np.array(Euler[1]).astype(np.float64)]
    yaw = [np.array(Euler[2]).astype(np.float64)]
    return np.array([x, y, z, roll, pitch, yaw])

def xyz_euler(A):

    """
    Extract translation and orientation in euler angles

    Args:
        A: Homogeneous transformation --> np.array((4, 4))

    Returns: x, y, z, roll, pitch, yaw --> np.array((1, 6))
             x, y, z --> [m]
             roll, pitch, yaw -- > [degrees]

    Important note: use numpy arrays

    """
    x = np.array(A[0, -1]).astype(np.float64)
    y = np.array(A[1, -1]).astype(np.float64)
    z = np.array(A[2, -1]).astype(np.float64)
    R = Rotation.from_matrix(A[:3, :3])
    # Euler = R.as_rotvec(degrees=True)
    Euler = R.as_euler('xyz', degrees=True)

    roll = np.array(Euler[0]).astype(np.float64)
    pitch = np.array(Euler[1]).astype(np.float64)
    yaw = np.array(Euler[2]).astype(np.float64)
    return np.array([x, y, z, roll, pitch, yaw])


def traj_gen_config(q1, q2, t, Tf):
    ''' path plan configuration space '''
    qm = q1 + (q2 - q1)/2
    a0 = q1
    a1 = np.zeros((6,))
    a4 = (qm - 0.5 * (q1 + q2)) / ((Tf / 2) ** 4)
    a3 = (2 * (q1 - q2) / (Tf ** 3)) - 2 * Tf * a4
    a2 = -1.5 * a3 * Tf - 2 * a4 * Tf ** 2

    q = a0 + a1 * t + a2 * t ** 2 + a3 * t ** 3 + a4 * t ** 4
    dq = a1 + 2 * a2 * t + 3 * a3 * t ** 2 + 4 * a4 * t ** 3
    ddq = 2 * a2 + 6 * a3 * t + 12 * a4 * t ** 2

    return q, dq, ddq

def traj_gen_task(x_s, x_g, t, Tf):

    """
    path plan in Task space
    x_s = Start point cartesian
    x_g = goal point cartesian
    """
    # x_s = np.array(list(x_s))   #start point
    # x_g = np.array(list(x_g))   #goal point
    a0 = 0. # np.zeros((3,))
    a1 = 0. # np.zeros((3,))
    a2 = 3 / Tf ** 2
    a3 = -2 / Tf ** 3
    x = x_s + (a0 + a1 * t + a2 * t ** 2 + a3 * t ** 3) * (x_g - x_s)
    dx = (a1 + 2 * a2 * t + 3 * a3 * t ** 2) * (x_g - x_s)
    ddx = (2 * a2 + 6 * a3 * t) * (x_g - x_s)

    return x, dx, ddx

def create_directory(location):
    '''
    creats a folder if not exsists, else does nothing
    '''
    if not os.path.isdir(location):
        os.makedirs(location)


def number_to_place(inty):
    '''
    input int 1 ,2 3
    output the coresspoding string 'First', 'Second', 'Third'
    '''
    places = ['First', 'Second', 'Third', 'Fourth', 'Fifth', 'Sixth', 'Seventh', 'Eighth', 'Ninth', 'Tenth']
    return places[inty-1]

def colum_extractor(The_list):
    '''
    input: matrix(list of lists), typaclly the path of xyz. for example: [[1,1,1],[2,2,2],[3,3,3], [4,4,4]]
    output: matrix, each coloum is now a list corrisponding column. for the example above: [[1,2,3,4],[1,2,3,4],[1,2,3,4]]
    '''
    workin_mat = The_list
    num_cols = len(The_list[0]) # get number of columns in matrix
    # extract columns using a loop
    columns_displacment = []
    for i in range(num_cols):
        columns_displacment.append([])
        for row in workin_mat:
            columns_displacment[i].append(row[i])
    return columns_displacment

def joints_to_xe_ye_ze(joints):
    '''
    input list 6 joints angles in degrees [°]
    output u,v,w coordinates in [m] for ax.quiver
    check matplotlib axes.quiver for more details
    '''
    # Euler angles
    Matrixe = FK(joints)
    lolo = xyz_euler(Matrixe)

    alpha1, alpha2, alpha3 = lolo[3], lolo[4], lolo[5]
    return euler_angle_to_xe_ye_ze([alpha1, alpha2, alpha3])

def euler_angle_to_xe_ye_ze(angles):
    '''
    input list 3 euler angles in degrees [°]
    output u,v,w coordinates in [m] for ax.quiver
    check matplotlib axes.quiver for more details
    '''
    phi, theta, psi = np.radians(angles[0]),np.radians(angles[1]),np.radians(angles[2])
    Rx = np.array([[1, 0, 0],
                   [0, np.cos(phi), -np.sin(phi)],
                   [0, np.sin(phi), np.cos(phi)]])

    Ry = np.array([[np.cos(theta), 0, np.sin(theta)],
                   [0, 1, 0],
                   [-np.sin(theta), 0, np.cos(theta)]])

    Rz = np.array([[np.cos(psi), -np.sin(psi), 0],
                   [np.sin(psi), np.cos(psi), 0],
                   [0, 0, 1]])
    rotation_matrix = np.matmul(np.matmul(Rx, Ry), Rz)
    unit_vector = np.matmul(rotation_matrix, np.array([0, 0, 1]))
    '''
    We multiply the rotation_matrix with vector (0, 0, 1) because the ende effector is
    pointing to the z direction when the euler angles are (0°,0°,0°)
    '''
    unit_vector /= np.linalg.norm(unit_vector)
    return unit_vector[0],unit_vector[1],unit_vector[2]


#lab 3

def TF_matrix(alpha, a, d, q):
    TF = Matrix([[cos(q), -cos(alpha) * sin(q), sin(q) * sin(alpha), a * cos(q)],
                 [sin(q), cos(alpha) * cos(q), -sin(alpha) * cos(q), a * sin(q)],
                 [0, sin(alpha), cos(alpha), d],
                 [0, 0, 0, 1]])
    return TF


def set_dh_table():
    dh_subs_dict = {alpha1: pi / 2, a1: 0, d1: 0.1283 + 0.1150, q1: q1,
                    alpha2: pi, a2: 0.280, d2: 0.030, q2: q2 + pi / 2,
                    alpha3: pi / 2, a3: 0, d3: 0.020, q3: q3 + pi / 2,
                    alpha4: pi / 2, a4: 0, d4: 0.1400 + 0.1050, q4: q4 + pi / 2,
                    alpha5: pi / 2, a5: 0, d5: 0.0285 + 0.0285, q5: q5 + pi,
                    alpha6: 0, a6: 0, d6: 0.1050 + 0.130, q6: q6 + pi / 2}
    return dh_subs_dict


def set_tranform_matrices():
    tf_matrices_list = []
    dh_params = set_dh_table()
    T_01 = TF_matrix(alpha1, a1, d1, q1).subs(dh_params)
    tf_matrices_list.append(T_01)
    T_12 = TF_matrix(alpha2, a2, d2, q2).subs(dh_params)
    tf_matrices_list.append(T_01 * T_12)
    T_23 = TF_matrix(alpha3, a3, d3, q3).subs(dh_params)
    tf_matrices_list.append(T_01 * T_12 * T_23)
    T_34 = TF_matrix(alpha4, a4, d4, q4).subs(dh_params)
    tf_matrices_list.append(T_01 * T_12 * T_23 * T_34)
    T_45 = TF_matrix(alpha5, a5, d5, q5).subs(dh_params)
    tf_matrices_list.append(T_01 * T_12 * T_23 * T_34 * T_45)
    T_56 = TF_matrix(alpha6, a6, d6, q6).subs(dh_params)
    tf_matrices_list.append(T_01 * T_12 * T_23 * T_34 * T_45 * T_56)
    Tes = Matrix([[0, -1, 0, 0], [1, 0, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
    T = T_01 * T_12 * T_23 * T_34 * T_45 * T_56 * Tes
    tf_matrices_list.append(T)
    return tf_matrices_list


def forward_hom_mat(theta_list):
    theta_dict = {}
    tf_matrices_list = set_tranform_matrices()
    T_0G = tf_matrices_list[-1]

    for i in range(len(theta_list)):
        theta_dict[q[i]] = theta_list[i]

    return T_0G.evalf(subs=theta_dict, chop=True, maxn=4)


def create_jacobian_syms():
    tf_matrices_list = set_tranform_matrices()

    T_0G = tf_matrices_list[-1]  # Get homogeneous transformation between base to TCP
    jacobian_mat = [diff(T_0G[:3, -1], q[i]).reshape(1, 3) for i in range(len(q))]
    jacobian_mat = Matrix(jacobian_mat).T
    temp = Matrix([0, 0, 1])
    for index in range(len(tf_matrices_list) - 2):
        temp = temp.col_insert(index + 1, tf_matrices_list[index][:3, 2])

    return Matrix(BlockMatrix([[jacobian_mat], [temp]]))


def LinearJacobian(Q):
    jacobian_mat_syms = create_jacobian_syms()
    return np.matrix(jacobian_mat_syms.evalf(subs=Q,  # Get only the linear Jacobian
                                             chop=True,
                                             maxn=4)).astype(np.float64)[:3, :]


def Jacobian(Q):
    jacobian_mat_syms = create_jacobian_syms()
    return np.matrix(jacobian_mat_syms.evalf(subs=Q,
                                             chop=True,
                                             maxn=4)).astype(np.float64)


def IK_NR_position(guess, target):
    lr = 0.05
    counter = 0
    theta_dict = {}
    Q = guess  # Initial Guess - Joint Angles
    p_d = target
    error = 100

    while error > 1e-2:

        for i in range(len(Q)):
            theta_dict[q[i]] = Q[i]

        print('Iteration: ' + str(counter) + '   Joint angles: ' + str(np.rad2deg(Q)))

        T = np.array(forward_hom_mat(Q)).astype(np.float64)  # Get transformation between base to EE
        p = T[:3, 3].reshape((3,))  # Extract Rotation matrix

        J = LinearJacobian(theta_dict)
        Q = Q + lr * np.linalg.pinv(J).dot(p_d - p)  # Update Q
        Q = np.array(Q).astype(np.float64)
        Q = Q[0]

        error = np.linalg.norm(p_d - p)
        print('current error: ', error)
        counter += 1
        print()

    return Q
