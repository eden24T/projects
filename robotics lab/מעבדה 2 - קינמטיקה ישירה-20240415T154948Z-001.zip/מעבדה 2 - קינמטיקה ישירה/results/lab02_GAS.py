import numpy as np
from sympy import *
from scipy.spatial.transform import Rotation
import pandas as pd
import statistics


alpha1, alpha2, alpha3, alpha4, alpha5, alpha6 = symbols('alpha1:7')
a1, a2, a3, a4, a5, a6 = symbols('a1:7')
d1, d2, d3, d4, d5, d6 = symbols('d1:7')
q1, q2, q3, q4, q5, q6 = symbols('q1:7')
theta_1,theta_2,theta_3,theta_4,theta_5,theta_6=symbols('theta1:7')

theta_list=[theta_1,theta_2,theta_3,theta_4,theta_5,theta_6]
def set_dh_table():
    """

    Returns: dictionary

    Important: all length arguments in [m]
               all angles argument in [radians]

    """

    dh_subs_dict = {alpha1: pi / 2, a1: 0, d1: (128.5 + 115) / 1000, q1: q1,
                    alpha2: pi, a2: 0.28, d2: 0.03, q2: q2 + pi / 2,
                    alpha3: pi / 2, a3: 0, d3: 0.02, q3: q3 + pi / 2,
                    alpha4: pi / 2, a4: 0, d4: 0.245, q4: q4 + pi / 2,
                    alpha5: pi / 2, a5: 0, d5: 0.057, q5: q5 + pi,
                    alpha6: 0, a6: 0, d6: 0.235, q6: q6 + pi / 2}

    return dh_subs_dict


def dh(alpha, a, d, theta):
    """
    Args:
        alpha: torsion angle
        a: distance
        d: translation
        theta: rotation angle

    Returns: Homogeneous DH matrix

    Important note: use sympy cos/sin arguments instead of math/numpy versions.
    i.e: cos(theta) \ sin(theta)

    """
    DH = Matrix([[cos(theta), -sin(theta) * cos(alpha), sin(theta) * sin(alpha), a * cos(theta)],
                 [sin(theta), cos(theta) * cos(alpha), -cos(theta) * sin(alpha), a * sin(theta)],
                 [0, sin(alpha), cos(alpha), d], [0, 0, 0, 1]]
                )
    return DH


def FK(theta_list):
    """
    Args:
        theta_list: joint angle vector ---> list [1,6]
    Returns:
        End effector homogeneous matrix --> Matrix((4, 4))

    Hints:
        - we have added a sympy implementation with missing parts, u dont have to use the same method.
        - chain 'Tes' to T_06 at the end.
    """
    table = set_dh_table()

    T_01 = dh(table[alpha1], table[a1], table[d1], table[q1])
    T_12 = dh(table[alpha2], table[a2], table[d2], table[q2])
    T_23 = dh(table[alpha3], table[a3], table[d3], table[q3])
    T_34 = dh(table[alpha4], table[a4], table[d4], table[q4])
    T_45 = dh(table[alpha5], table[a5], table[d5], table[q5])
    T_56 = dh(table[alpha6], table[a6], table[d6], table[q6])
    Tes = Matrix([[0, -1, 0, 0], [1, 0, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])  # mandatory
    T = T_01 * T_12 * T_23 * T_34 * T_45 * T_56 * Tes

    ''' fill angles to dict for sympy calculations'''

    theta_dict = {}
    keys = [q1, q2, q3, q4, q5, q6]
    for i in range(len(theta_list)):
        theta_dict[keys[i]] = theta_list[i]
    ''' 
    homogeneous transformation matrix from base_link to end_effector [type: numeric matrix] 
    because we are using sympy, we have to use evalf.
    '''
    T_0G_eval = T.evalf(subs=theta_dict, chop=True, maxn=4)

    return T_0G_eval

print("DOR",FK([0.10472,5.32325,1.35787,4.81013,5.47161,6.21337]))

def xyz_eulerm(A):
    """
    Extract translation and orientation in euler angles

    Args:
        A: Homogeneous transformation --> np.array((4, 4))

    Returns: x, y, z, thetax, thetay, thetaz --> np.array((1, 6))

    Important note: use numpy arrays

    """
    M = np.copy(A)
    M = M[:, -1]
    M = M[:-1]

    R = Rotation.from_matrix(A[:3, :3])
    M2 = R.as_euler('xyz', degrees=True)

    yaw = [np.array(M2[2]).astype(np.float64)]
    roll = [np.array(M2[0]).astype(np.float64)]
    pitch = [np.array(M2[1]).astype(np.float64)]

    arrayte = np.append(M, roll)
    arrayte = np.append(arrayte, pitch)
    arrayte = np.append(arrayte, yaw)

    return np.array([M, roll, pitch, yaw])

def xyz_euler(A):

    """
    Extract translation and orientation in euler angles

    Args:
        A: Homogeneous transformation --> np.array((4, 4))

    Returns: x, y, z, roll, pitch, yaw --> np.array((1, 6))
             x, y, z --> [m]
             roll, pitch, yaw -- > [degrees]

    Important note: use numpy arrays

    """
    x = [np.array(A[0, -1]).astype(np.float64)]
    y = [np.array(A[1, -1]).astype(np.float64)]
    z = [np.array(A[2, -1]).astype(np.float64)]
    R = Rotation.from_matrix(A[:3, :3])
    # Euler = R.as_rotvec(degrees=True)
    Euler = R.as_euler('xyz', degrees=True)

    roll = [np.array(Euler[0]).astype(np.float64)]
    pitch = [np.array(Euler[1]).astype(np.float64)]
    yaw = [np.array(Euler[2]).astype(np.float64)]
    return np.array([x, y, z, roll, pitch, yaw])

def angles_to_follow():
    """

    Returns: Dictionary of the desired angels

    """

    angles = { 't1': [6.244543718,0.205006374 ,2.528057062 , 4.747313019, 5.754333091, 4.771695268],
               't2': [    0.21685716,    5.188549707 ,    5.785487218,    5.477244618,    4.939857742,    4.816323337 ],
                't3': [1.791510664,5.272534951 , 6.060097322,4.41018522 ,4.872383313 , 5.451832625],
                't4': [0.803549588,5.606713142 ,1.354619846 ,5.300093699 , 4.803809327, 0.213959913],
                't5': [0.103271132, 5.470490194, 1.843957808, 4.959719589, 4.499912597,5.949460901 ],
               't6': [0.546672028, 4.717590062, 5.494802631,  4.531869576, 5.41809541,  6.172339446],
               't7':   [1.059135603, 5.721032208, 6.184190232, 4.027556688, 4.967329224,     0.049078659],
               't8':   [4.913328737,    5.150361903,     0.494504137,     0.213244328,     4.67989095,  6.172601246],
               't9':   [5.511505432,     5.31255535,     1.182600195,     5.955587007,     5.659369726,     6.03951989],
               't10': [5.747753199,    5.283006926,     0.66844365,     5.360726438,  5.554318358,  0.601196114],}  # [radians]
    #
    #
    return angles




#print(FK(theta_list))

#theta_list_1=[6.244543718,0.205006374 ,2.528057062 , 4.747313019, 5.754333091, 4.771695268]
#theta_list_2=[    0.21685716,    5.188549707 ,    5.785487218,    5.477244618,    4.939857742,    4.816323337 ]
#theta_list_3=[1.791510664,5.272534951 , 6.060097322,4.41018522 ,4.872383313 , 5.451832625]
#theta_list_4=[0.803549588,5.606713142 ,1.354619846 ,5.300093699 , 4.803809327, 0.213959913]
#theta_list_5=[0.103271132, 5.470490194, 1.843957808, 4.959719589, 4.499912597,5.949460901 ]
#theta_list_6=[0.546672028, 4.717590062, 5.494802631,  4.531869576, 5.41809541,  6.172339446]
#theta_list_7=[1.059135603, 5.721032208, 6.184190232, 4.027556688, 4.967329224,     0.049078659]
#theta_list_8=[4.913328737,    5.150361903,     0.494504137,     0.213244328,     4.67989095,  6.172601246]
#theta_list_9= [5.511505432,     5.31255535,     1.182600195,     5.955587007,     5.659369726,     6.03951989]


# theta_list_10=[5.747753199,    5.283006926,     0.66844365,     5.360726438,  5.554318358,  0.601196114]
# Tee=FK(theta_list_10)
# print(Tee)






####################
#####EDEN
####################


x=[0.386,0.243,0.054,0.223,0.435,0.424,-0.028,-0.247,-0.089,-0.078]
x2=[0.39,0.24,0.05,0.22,0.44,0.42,-0.03,-0.25,-0.09,-0.08]

y=[-0.108,-0.22,-0.147,-0.368,-0.297,-0.323,-0.449,-0.455,-0.61,-0.376]
y2=[-0.11,-0.22,-0.15,-0.37,-0.3,-0.32,-0.45,-0.45,-0.61,-0.38]

z=[0.479,0.344,0.178,0.137,0.087,0.46,0.424,0.222,0.127,0.621]
z2=[0.48,0.34,0.18,0.14,0.09,0.46,0.42,0.22,0.13,0.62]

theta_x = [88.5, 88.5, 88.5, 88.8, 89.1, 78.7, 77.85, 77.8, -42.7, -44]
theta_x2 = [88.45, 88.55, 88.52, 88.82, 89.14, 78.6, 77.78, 77.6, -42.5, -43.92]

theta_y = [0.81, 0.8, 0.92, 0.82, 0.77, 5.3, 3.5, 3.65, -121.8, -121.6]
theta_y2 = [0.796, 0.792, 0.91, 0.82, 0.78, 5.35, 3.42, 3.64, -121.4, -121.56]
theta_z = [130.6, 130.6, 130.6, 129.3, 127.9, 121.6, 30.9, 9.39, 156.74, 164.6]
theta_z2 = [130.442, 130.255, 130.65, 129.2, 127.6, 121.4, 31.2, 9.83, 156.72, 164.55]




print('mort\n\n')
std_x=[]
for i in range(len(x)):
    std_x_i=np.std([x[i],x2[i]])
    std_x.append(std_x_i)
print('std_x', std_x)

print('mort\n')

std_y=[]
for i in range(len(y)):
    std_y_i=np.std([y[i],y2[i]])
    std_y.append(std_y_i)    
print('std_y', std_y)
print('mort\n')

std_z=[]
for i in range(len(z)):
    std_z_i=np.std([z[i],z2[i]])
    std_z.append(std_z_i) 
print('std_z', std_z)

print('mort\n')


std_theta_x=[]
for i in range(len(theta_x)):
    std_theta_x_i=np.std([theta_x[i],theta_x2[i]])
    std_theta_x.append(std_theta_x_i)
print(std_theta_x)
print('mort\n')


std_theta_y=[]
for i in range(len(theta_y)):
    std_theta_y_i=np.std([theta_y[i],theta_y2[i]])
    std_theta_y.append(std_theta_y_i) 
print(std_theta_y)
print('mort\n')


std_theta_z=[]
for i in range(len(theta_z)):
    std_theta_z_i=np.std([theta_z[i],theta_z2[i]])
    std_theta_z.append(std_theta_z_i)
print(std_theta_z)
print('mort\n')


mean_x=[]
for i in range(len(x)):
    mean_x_i=statistics.mean([x[i],x2[i]])
    mean_x.append( mean_x_i)
print('mean_x',mean_x)
print('mort\n')
mean_y=[]
for i in range(len(y)):
    mean_y_i=statistics.mean([y[i],y2[i]])
    mean_y.append( mean_y_i)
print('mean_y',mean_y)

print('mort\n')
mean_z=[]
for i in range(len(z)):
    mean_z_i=statistics.mean([z[i],z2[i]])
    mean_z.append( mean_z_i)
print('mean_z',mean_z_i)

print('mort\n')
mean_theta_x=[]
for i in range(len(x)):
    mean_theta_x_i=statistics.mean([theta_x[i],theta_x2[i]])
    mean_theta_x.append( mean_theta_x_i)
print('mean_theta_x',mean_theta_x)
print('mort\n')

mean_theta_y=[]
for i in range(len(y)):
    mean_theta_y_i=statistics.mean([theta_y[i],theta_y2[i]])
    mean_theta_y.append( mean_theta_y_i)
print('mean_theta_y',mean_theta_y)

print('mort\n')
mean_theta_z=[]
for i in range(len(z)):
    mean_theta_z_i=statistics.mean([theta_z[i],theta_z2[i]])
    mean_theta_z.append(mean_theta_z_i)
print('mean_theta_z',mean_theta_z)
print('done')