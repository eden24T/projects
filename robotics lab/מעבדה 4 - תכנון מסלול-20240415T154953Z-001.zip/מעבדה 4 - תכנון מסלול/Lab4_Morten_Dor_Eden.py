from tabulate import tabulate
import numpy as np
import pickle
import os
import glob
import matplotlib.pyplot as plt
import Morten_Robotics


locy = r'C:\Users\Morten\OneDrive - mail.tau.ac.il\לימודים משותפים\מעבדות\שנה ד\סמסטר ב\מעבדה ברובוטיקה ובקרה של מערכות\מעבדה 4 - תכנון מסלול'
locy = r'C:\Users\selic\OneDrive - mail.tau.ac.il\מעבדה ברובוטיקה ובקרה של מערכות\מעבדה 4 - תכנון מסלול'
data_path = os.path.join(locy, 'RESULTS LAB', 'data')

def create_directory(location):
    '''
    creats a folder if not exsists, else does nothing
    '''
    if not os.path.isdir(location):
        os.makedirs(location)

create_directory(locy+'//Plots')


def number_to_place(inty):
    '''
    input int 1 ,2 3
    output the coresspoding string 'First', 'Second', 'Third'
    '''
    places = ['First', 'Second', 'Third', 'Fourth', 'Fifth', 'Sixth', 'Seventh', 'Eighth', 'Ninth', 'Tenth']
    return places[inty-1]

def colum_extractor(The_list):
    '''
    input: matrix(list of lists), typaclly the path of xyz. for example: [[1,1,1],[2,2,2],[3,3,3], [4,4,4]]
    output: matrix, each coloum is now a list corrisponding column. for the example above: [[1,2,3,4],[1,2,3,4],[1,2,3,4]]
    '''
    workin_mat = The_list
    num_cols = len(The_list[0]) # get number of columns in matrix
    # extract columns using a loop
    columns_displacment = []
    for i in range(num_cols):
        columns_displacment.append([])
        for row in workin_mat:
            columns_displacment[i].append(row[i])
    return columns_displacment

def joints_to_xe_ye_ze(joints):
    '''
    input list 6 joints angles in degrees [°]
    output u,v,w coordinates in [m] for ax.quiver
    check matplotlib axes.quiver for more details
    '''
    # Euler angles
    Matrixe = Morten_Robotics.FK(joints)
    lolo = Morten_Robotics.xyz_euler(Matrixe)

    alpha1, alpha2, alpha3 = lolo[3], lolo[4], lolo[5]
    return euler_angle_to_xe_ye_ze([alpha1, alpha2, alpha3])

def euler_angle_to_xe_ye_ze(angles):
    '''
    input list 3 euler angles in degrees [°]
    output u,v,w coordinates in [m] for ax.quiver
    check matplotlib axes.quiver for more details
    '''
    phi, theta, psi = np.radians(angles[0]),np.radians(angles[1]),np.radians(angles[2])
    Rx = np.array([[1, 0, 0],
                   [0, np.cos(phi), -np.sin(phi)],
                   [0, np.sin(phi), np.cos(phi)]])

    Ry = np.array([[np.cos(theta), 0, np.sin(theta)],
                   [0, 1, 0],
                   [-np.sin(theta), 0, np.cos(theta)]])

    Rz = np.array([[np.cos(psi), -np.sin(psi), 0],
                   [np.sin(psi), np.cos(psi), 0],
                   [0, 0, 1]])
    rotation_matrix = np.matmul(np.matmul(Rx, Ry), Rz)
    unit_vector = np.matmul(rotation_matrix, np.array([0, 0, 1]))
    '''
    We multiply the rotation_matrix with vector (0, 0, 1) because the ende effector is
    pointing to the z direction when the euler angles are (0°,0°,0°)
    '''
    unit_vector /= np.linalg.norm(unit_vector)

    return unit_vector[0],unit_vector[1],unit_vector[2]



# RAW THEORTICAL DATA
dict_of_rounds_xyz= {
    0: np.array([[0.44, 0.187, 0.419, 96, 1, 150],
                [0.369, -0.015, 0.21, 178, 3, 177],
                [0.372, 0.014, 0.01, 178, 4.5, 175],
                [0.44, 0.187, 0.419, 96, 1, 150]]),
    1:np.array([[0.3, 0.18, 0.39, 98, 1.1, 153],
               [0.36,-0.015,0.25,175,2.69,171],
               [0.37,0.015,0.012,175,4.1,177],
               [0.4,0.182,0.416,91,0.9,152]]),
    2:np.array([[0.3, 0.18, 0.39, 98, 1.1, 153],
               [0.36,-0.015,0.25,175,2.69,171],
               [0.37,0.015,0.012,175,4.1,177],
               [0.4,0.182,0.416,91,0.9,152]]),
    3:np.array([[0.44, 0.187, 0.419, 96, 1, 150],
                [0.369, -0.015, 0.21, 178, 3, 177],
                [0.372, 0.014, 0.01, 178, 4.5, 175],
                [0.44, 0.187, 0.419, 96, 1, 150]]),
    4:np.array([[0.44, 0.187, 0.419, 96, 1, 150],
                [0.369, -0.015, 0.21, 178, 3, 177],
                [0.372, 0.014, 0.01, 178, 4.5, 175],
                [0.44, 0.187, 0.419, 96, 1, 150]]),

    5:np.array([[0.44, 0.187, 0.419, 96, 1, 150],
                [0.369, -0.015, 0.21, 178, 3, 177],
                [0.372, 0.014, 0.01, 178, 4.5, 175],
                [0.44, 0.187, 0.419, 96, 1, 150]]),
    #5:np.array([[0.439,0.193,0.448,90.66,-0.901,150.003],
    #            [0.441,-0.145,0.211,176.25,12.939,177.447],
    #            [0.45,-0.128,-0.002,176.301,12.896,177.42],
    #          [0.327,-0.357,0.104,176.232,12.852,177.458]])
}


dict_of_rounds_joints= {
    0: np.array([[0.1, 343, 75, 354, 300, 0.1],
                [7.5, 337, 80, 271, 287, 10],
                [7.5, 313, 97, 272, 329, 10],
                [0.1, 343, 75, 354, 300, 0.1]]),
    1:np.array([[0.12, 340, 69, 348, 302, 0.098],
                [7.3, 340, 77, 275, 280, 11],
                [7.9, 310, 92, 270, 317, 8],
                [0.09, 340, 81, 353, 302, 0.132]]),
    2:np.array([[0.12, 340, 69, 348, 302, 0.098],
                [7.3, 340, 77, 275, 280, 11],
                [7.9, 310, 92, 270, 317, 8],
                [0.09, 340, 81, 353, 302, 0.132]]),
    3:np.array([[0.1, 343, 75, 354, 300, 0.1],
               [7.5, 337, 80, 271, 287, 10],
               [7.5, 313, 97, 272, 329, 10],
               [0.1, 343, 75, 354, 300, 0.1]]),
    4:np.array([[0.1, 343, 75, 354, 300, 0.1],
               [7.5, 337, 80, 271, 287, 10],
               [7.5, 313, 97, 272, 329, 10],
               [0.1, 343, 75, 354, 300, 0.1]]),
    5:np.array([[0.1, 343, 75, 354, 300, 0.1],
               [7.5, 337, 80, 271, 287, 10],
               [7.5, 313, 97, 272, 329, 10],
               [0.1, 343, 75, 354, 300, 0.1]]),          
    #5:np.array([[359,343,75,359,299,369],
    #          [347.037,322.568,57.288,276.275,286.694,347.991],
    #          [348.481,302.343,73.045,278.975,322.639,345.072],
    #          [314.784,306.955,52.91,282.417,292.425,312.798]])
}

'''
data is a list, every element is a route.
each route is a list of 2 elements first element is path of angles, second element is path of x y z
hence data[i][0] - path of angles data[i][1] - path of x y z. each path consist of len(data[i][0]) elements
'''

# user must choose!
user_input = input('Would you like to show the plot? hit yes (y), if you wish only to save them hit no (n) (y/n): ')
howlong = 1
while not (user_input == 'n' or user_input == 'y'):
    print('Try again sir, its your {} try!'.format(howlong))
    howlong = howlong + 1
    user_input = input('Would you like to show the plot? hit yes (y), if you wish only to save them hit no (n) (y/n): ')
    if howlong >=5:
        print('you are brobably a robot')
        user_input = 'n'

data = []
for file in glob.glob(data_path + '/*/*.pkl'):
    with open(file, 'rb') as h:
        data.append(pickle.load(h))

best_vetors = []
for ind, section in enumerate(data):

    columns_displacment = colum_extractor(section[1])
    columns_angles = colum_extractor(section[0])

    # theoritical part
    theo_xyz = dict_of_rounds_xyz[ind]
    theo_angle = dict_of_rounds_joints[ind]
    
    #creating theortical path
    theortical_path = []
    
    for everyone in range(len(dict_of_rounds_xyz[ind])-1):
        onu, doss = dict_of_rounds_xyz[ind][everyone][:3], dict_of_rounds_xyz[ind][everyone+1][:3]
        for alti in np.linspace(0, 1, int(len(section[1])/3)):
            theortical_path.append(Morten_Robotics.traj_gen_task(onu, doss, alti, 5)[0].tolist())
    theortical_columns_displacment = colum_extractor(theortical_path)
   
    # Start Plotiing
    fig = plt.figure(figsize=(12,9))
    ax = fig.add_subplot(projection = '3d')

    #this loop plot the vectors and the blue point of the theortical
    for indyyd, elyo in enumerate(theo_xyz):
        xe1, ye1, ze1 = euler_angle_to_xe_ye_ze(elyo[3:])
        ax.quiver(elyo[0], elyo[1], elyo[2], xe1, ye1, ze1, length=0.08)
        ax.scatter(elyo[0], elyo[1], elyo[2], color='blue')

    first_point = section[1][0]
    last_point = section[1][-1]

    a, b, c = last_point[0], last_point[1], last_point[2]

    # Euler angles
    xe, ye, ze = joints_to_xe_ye_ze(section[0][-1])
    
    # Plot the arrow
    ax.quiver(a, b, c, xe, ye, ze, length=0.08, color = 'green')

    ax.plot3D(columns_displacment[0], columns_displacment[1], columns_displacment[2], 'Black')
    ax.plot3D(theortical_columns_displacment[0], theortical_columns_displacment[1], theortical_columns_displacment[2], 'pink')

    ax.scatter(first_point[0], first_point[1], first_point[2], color='red', s=100)
    ax.scatter(last_point[0], last_point[1], last_point[2], color='Green', s=100)

    ax.set_xlabel('x [m]', fontsize = 12)
    ax.set_ylabel('y [m]', fontsize = 12)
    ax.set_zlabel('z [m]', fontsize = 12)

    #autumatic' checks only the boundaries of the real path
    ax.set_xlim(1.1*min(columns_displacment[0]) if min(columns_displacment[0])<0 else 0.9*min(columns_displacment[0]),
                 1.2*max(columns_displacment[0]) if max(columns_displacment[0])>0 else 0.9*max(columns_displacment[0]))
    ax.set_ylim(1.1*min(columns_displacment[1]) if min(columns_displacment[1])<0 else 0.9*min(columns_displacment[1]),
                 1.2*max(columns_displacment[1]) if max(columns_displacment[1])>0 else 0.9*max(columns_displacment[1]))
    ax.set_zlim(1.1*min(columns_displacment[2]) if min(columns_displacment[2])<0 else 0.9*min(columns_displacment[2]),
                 1.2*max(columns_displacment[2]) if max(columns_displacment[2])>0 else 0.9*max(columns_displacment[2]))
    
    #lets use manual istead
    ax.set_xlim(0, 0.8)
    ax.set_ylim(-0.3, 0.4)
    ax.set_zlim(0, 0.8)

    #title and other shit
    ax.set_title(number_to_place(ind+1)+' Route', fontsize = 16)
    plt.savefig(locy+'//Plots//LAB 4 Route '+str(ind+1)+'.svg', bbox_inches='tight', transparent=True)
    if user_input == 'y':
        plt.show()
    plt.close()

    # Find the closest vector
    closest_vectors_places = []
    the_sum_error = 0
    for funny, elyo2 in enumerate(theo_xyz):
        elyo = np.array(elyo2[:3])
        to_hit = np.array(section[1][0])
        currenly_best = np.dot(elyo/np.linalg.norm(elyo), to_hit/np.linalg.norm(to_hit))
        the_placyy_wow = 0
        for the_place in range(1, len(section[1])):
            to_hit = np.array(section[1][the_place])
            turu = np.dot(elyo/np.linalg.norm(elyo), to_hit/np.linalg.norm(to_hit))

            if turu>currenly_best:
                currenly_best = turu
                the_placyy_wow = the_place
        closest_vectors_places.append(the_placyy_wow)
        
        #calculating the error.
        averageer = np.abs(np.average((elyo-section[1][the_placyy_wow])/np.maximum(elyo, section[1][the_placyy_wow])))
        the_sum_error =+ averageer
    best_vetors.append(closest_vectors_places)
    for_print=section[1][closest_vectors_places]
    print('\n\n')
    print('For the {} run the average error is: {} %'.format(number_to_place(ind+1), round(the_sum_error/4*100,3)))
    print("real \n",for_print)
    print("\ntherotetical\n",dict_of_rounds_xyz[funny])
    


print('The best vectors are: ', best_vetors)
print('Done')