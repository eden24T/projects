import numpy as np

def traj_gen_config(q1, q2, t, Tf):
    ''' path plan configuration space '''
    qm = q1 + (q2 - q1)/2
    a0 = q1
    a1 = np.zeros((6,))
    a4 = (qm - 0.5 * (q1 + q2)) / ((Tf / 2) ** 4)
    a3 = (2 * (q1 - q2) / (Tf ** 3)) - 2 * Tf * a4
    a2 = -1.5 * a3 * Tf - 2 * a4 * Tf ** 2

    q = a0 + a1 * t + a2 * t ** 2 + a3 * t ** 3 + a4 * t ** 4
    dq = a1 + 2 * a2 * t + 3 * a3 * t ** 2 + 4 * a4 * t ** 3
    ddq = 2 * a2 + 6 * a3 * t + 12 * a4 * t ** 2

    return q, dq, ddq

def traj_gen_task(x_s, x_g, t, Tf):

    """
    path plan in Task space
    x_s = Start point cartesian
    x_g = goal point cartesian
    """
    # x_s = np.array(list(x_s))   #start point
    # x_g = np.array(list(x_g))   #goal point
    a0 = 0. # np.zeros((3,))
    a1 = 0. # np.zeros((3,))
    a2 = 3 / Tf ** 2
    a3 = -2 / Tf ** 3
    x = x_s + (a0 + a1 * t + a2 * t ** 2 + a3 * t ** 3) * (x_g - x_s)
    dx = (a1 + 2 * a2 * t + 3 * a3 * t ** 2) * (x_g - x_s)
    ddx = (2 * a2 + 6 * a3 * t) * (x_g - x_s)

    return x, dx, ddx

def generate_x_goals_list():
    """

    Returns: list of

    """
    x_ = np.array([[0.52, 0.190, 0.416, 97, 1.1, 143],
                   [0.370, -0.013, 0.21, 170, 3.2, 170],
                   [0.370, 0.02, 0.001, 180, 5.1, 177],
                   [0.5, 0.181, 0.41, 92, 1.3, 146]])
    return x_


def generate_q_goals_list():
    """

    Returns: list of

    """
    jointPoses = np.array([[0.12, 341, 77, 350, 305, 0.102],
                           [7.9, 339, 83, 268, 282, 11.5],
                           [7.9, 315, 100.2, 270, 333, 11],
                           [20, 350, 73, 349, 33, 0.13]])


    return jointPoses