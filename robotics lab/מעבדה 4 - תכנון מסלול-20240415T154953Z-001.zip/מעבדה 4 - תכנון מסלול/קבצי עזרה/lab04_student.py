import numpy as np


#######################
######## Lab 4 ########
#######################
start=np.array([0,0,0,0,0,0])
goal=np.array([0.5,0.5,1,90,20,0])
time=1
total_time=3

def traj_gen_config(q1, q2, t, Tf):
    """
    path plan configuration space

    Args:
        q1: Start configuration (angles) [degrees] --> np.array((6,))
        q2: Goal configuration (angles) [degrees] --> np.array((6,))
        t: Time instance --> float
        Tf: Total movement time --> float

    Returns: angles positions, angles velocities, angles accelerations
                --> q, dq, ddq --> 3 object of np.array((6,))

    """

    U1=[]
    t_sec=t*Tf
    #computing the joint angles acoording to the WORD document
    theta_mid = np.zeros((6))
    theta_mid_polinomial = np.zeros((6))
    for joint in range(np.shape(q1)[0]):
        U1.append((q2[joint]-q1[joint])/(Tf/2)) #[deg/s]
        theta_i=q1[joint]*(1-t)+q2[joint]*t
        theta_mid[joint]=theta_i

        theta_i_polinomial=q1[joint]+10*(q2[joint]-q1[joint])/(Tf**3)*t_sec**3+15*(q1[joint]-q2[joint])/(Tf**4)*t_sec**4+6*(q2[joint]-q1[joint])/(Tf**5)*t_sec**5
        theta_mid_polinomial[joint]=theta_i_polinomial
    
    #computing the velocities acoording to the WORD document
    theta_dot_mid=np.zeros((6))
    theta_dot_mid_polinomial = np.zeros((6))
    for joint in range(np.shape(q1)[0]):
        U=U1[joint]
        if t<=0.25:
            theta_dot_i=((48*U)/(Tf**2))*t_sec**2-(128*U)/(Tf**3)*t_sec**3
            theta_dot_mid[joint]=theta_dot_i
        elif 0.25<t and t<=0.75:
            theta_dot_i=U
            theta_dot_mid[joint]=theta_dot_i
        elif  0.75<=t:
            theta_dot_i=-80*U+(288*U/Tf)*t_sec-(336*U/(Tf**2))*t_sec**2+(128*U/(Tf**3))*t_sec**3
            theta_dot_mid[joint]=theta_dot_i

        
        theta_dot_mid_i_polinomial = 30*(q2[joint]-q1[joint])/(Tf**3)*t_sec**2+4*15*(q1[joint]-q2[joint])/(Tf**4)*t_sec**3+5*6*(q2[joint]-q1[joint])/(Tf**5)*t_sec**4
        theta_dot_mid_polinomial[joint]=theta_dot_mid_i_polinomial       

    #computing the accelerations acoording to the WORD document
    theta_dotaim_mid=np.zeros((6))
    theta_dotaim_mid_polinomial=np.zeros((6))
    for joint in range(np.shape(q1)[0]):
        U=U1[joint]
        if t<=0.25:
            theta_dotaim_i=(96*U*t_sec)/(Tf**2)-(3*128*U*t_sec**2)/(Tf**3)
            theta_dotaim_mid[joint]=theta_dotaim_i
        elif 0.25<t and t<=0.75:
            continue
        elif  0.75<=t:
            theta_dotaim_i=(288*U)/Tf-(2*336*U*t_sec)/(Tf**2)+(3*128*U*t_sec**2)/(Tf**3)
            theta_dotaim_mid[joint]=theta_dotaim_i


        
        theta_dotaim_mid_i_polinomial = 6*10*(q2[joint]-q1[joint])/(Tf**3)*t_sec+12*15*(q1[joint]-q2[joint])/(Tf**4)*t_sec**2+20*6*(q2[joint]-q1[joint])/(Tf**5)*t_sec**3
        theta_dotaim_mid_polinomial[joint]=theta_dotaim_mid_i_polinomial          
    
    return theta_mid_polinomial, theta_dot_mid_polinomial, theta_dotaim_mid_polinomial
    return theta_mid, theta_dot_mid, theta_dotaim_mid

 
    #pass



################## second function ##############

def traj_gen_task(x_s, x_g, t, Tf):
    """
    path plan in Task space

    Args:
        x_s: Start end-effector position and orientation UNITS:[m, degrees] --> np.array((6,))
        x_g: Goal end-effector position and orientation UNITS:[m, degrees] --> np.array((6,))
        t: Time instance --> float
        Tf: Total movement time --> float

    Returns: End-effector position, velocity, acceleration
                --> x, dx, ddx --> 3 object of np.array((6,))

    """

    U1=[]
    t_sec=t*Tf
    #computing the End-effector position and orientaion
        #position
    xyz_mid = np.zeros((6))
    xyz_mid_polinomial=np.zeros((6))
    xyz_mid=x_g*(1-t)+x_s*t
    for joint in range(np.shape(x_s)[0]):
        U1.append((x_g[joint]-x_s[joint])/(Tf/2)) #[deg/s]
        theta_i=x_g[joint]*(1-t)+x_s[joint]*t
        #xyz_mid[joint]=theta_i
        theta_i_polinomial=x_s[joint]+10*(x_g[joint]-x_s[joint])/(Tf**3)*t_sec**3+15*(x_s[joint]-x_g[joint])/(Tf**4)*t_sec**4+6*(x_g[joint]-x_s[joint])/(Tf**5)*t_sec**5
        xyz_mid_polinomial[joint]=theta_i_polinomial
    
    #computing the velocities acoording to the WORD document
    xyz_dot_mid=np.zeros((6))
    xyz_dot_mid_polinomial = np.zeros((6))
    for joint in range(np.shape(x_s)[0]):
        U=U1[joint]
        if t<=0.25:
            theta_dot_i=((48*U)/(Tf**2))*t_sec**2-(128*U)/(Tf**3)*t_sec**3
            xyz_dot_mid[joint]=theta_dot_i
        elif 0.25<t and t<=0.75:
            theta_dot_i=U
            xyz_dot_mid[joint]=theta_dot_i
        elif  0.75<=t:
            theta_dot_i=-80*U+(288*U/Tf)*t_sec-(336*U/(Tf**2))*t_sec**2+(128*U/(Tf**3))*t_sec**3
            xyz_dot_mid[joint]=theta_dot_i

        
        theta_dot_mid_i_polinomial = 30*(x_g[joint]-x_s[joint])/(Tf**3)*t_sec**2+4*15*(x_s[joint]-x_g[joint])/(Tf**4)*t_sec**3+5*6*(x_g[joint]-x_s[joint])/(Tf**5)*t_sec**4
        xyz_dot_mid_polinomial[joint]=theta_dot_mid_i_polinomial       

    #computing the accelerations acoording to the WORD document
    xyz_dotaim_mid=np.zeros((6))
    xyz_dotaim_mid_polinomial=np.zeros((6))
    for joint in range(np.shape(x_s)[0]):
        U=U1[joint]
        if t<=0.25:
            theta_dotaim_i=(96*U*t_sec)/(Tf**2)-(3*128*U*t_sec**2)/(Tf**3)
            xyz_dotaim_mid[joint]=theta_dotaim_i
        elif 0.25<t and t<=0.75:
            continue
        elif  0.75<=t:
            theta_dotaim_i=(288*U)/Tf-(2*336*U*t_sec)/(Tf**2)+(3*128*U*t_sec**2)/(Tf**3)
            xyz_dotaim_mid[joint]=theta_dotaim_i


        
        theta_dotaim_mid_i_polinomial = 6*10*(x_g[joint]-x_s[joint])/(Tf**3)*t_sec+12*15*(x_s[joint]-x_g[joint])/(Tf**4)*t_sec**2+20*6*(x_g[joint]-x_s[joint])/(Tf**5)*t_sec**3
        xyz_dotaim_mid_polinomial[joint]=theta_dotaim_mid_i_polinomial          
    
   # return xyz_mid_polinomial, xyz_dot_mid_polinomial, xyz_dotaim_mid_polinomial
    return xyz_mid, xyz_dot_mid, xyz_dotaim_mid

print(traj_gen_task(start,goal,time,total_time))

def generate_x_goals_list():
    """

    Returns: Desired end-effector goals along the planned path --> np.array((4, 6))

    Notes:  1. Position units [m]
            2. Orientation units [degrees]

    """
    pass


def generate_q_goals_list():
    """

    Returns: Desired configuration (angle) goals along the planned path --> --> np.array((4, 6))

    Notes: Orientation units [degrees]

    """

    pass
