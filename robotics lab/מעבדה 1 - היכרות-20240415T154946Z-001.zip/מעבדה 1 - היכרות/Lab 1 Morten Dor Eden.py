import numpy as np
import pickle
import os
import glob
import matplotlib.pyplot as plt

locy = r'C:\Users\Morten\OneDrive - mail.tau.ac.il\לימודים משותפים\מעבדות\שנה ד\סמסטר ב\מעבדה ברובוטיקה ובקרה של מערכות\מעבדה 1 - היכרות\נתונים'
data_path = os.path.join(locy, 'data')
snow_loc = r'C:\Users\Morten\OneDrive - mail.tau.ac.il\לימודים משותפים\מעבדות\שנה ד\סמסטר ב\מעבדה ברובוטיקה ובקרה של מערכות'
snow_path = os.path.join(snow_loc, 'Snow.jpg')

def create_directory(location):
    if not os.path.isdir(location):
        os.makedirs(location)
create_directory(locy+'//Plots//Q2')
create_directory(locy+'//Plots//Q3')

def number_to_place(inty):
    places = ['First', 'Second', 'Third', 'Fourth', 'Fifth', 'Sixth', 'Seventh', 'Eighth', 'Ninth', 'Tenth']
    return places[inty-1]

Hz = 2 #frequency [1/s]
data = []
data_for_q4 = []
for file in glob.glob(data_path + '/*/*.pkl'):
    with open(file, 'rb') as h:
        data.append(pickle.load(h))

for ind, section in enumerate(data):
    workin_mat = section[1]
    workin_mat2 = section[0]

    num_cols = len(workin_mat[0]) # get number of columns in matrix
    # extract columns using a loop
    columns_displacment = []
    for i in range(num_cols):
        columns_displacment.append([])
        if len(data_for_q4) < i+1:
            data_for_q4.append([])
        for row in workin_mat:
            columns_displacment[i].append(row[i])
            data_for_q4[i].append(row[i])
    
    
    workin_mat2 = section[0]
    num_cols2 = len(workin_mat2[0]) # get number of columns in matrix
    # extract columns using a loop
    columns_angles = []
    for i in range(num_cols2):
        columns_angles.append([])
        for row in workin_mat2:
            columns_angles[i].append(row[i])

# 2) Plot x,y,z with respect to time
    fig, ax = plt.subplots(figsize=(12,9))
    timey = np.linspace(0, len(columns_displacment[0])/Hz, len(columns_displacment[0]))
    min_bord = min(columns_displacment[0])
    max_bord = max(columns_displacment[0])

    # train
    # for i in range(1, len(columns_displacment)):
    #     min_bord= min(min(columns_displacment[i]), min_bord)
    #     max_bord= max(max(columns_displacment[i]), max_bord)

    # borders = [min(timey)*1, max(timey)*1, min_bord*1, max_bord*1]
    # ax.imshow(plt.imread(snow_path), extent = borders, aspect='auto')

    ax.plot(timey, columns_displacment[0], color = 'yellow', label = 'x')
    ax.plot(timey, columns_displacment[1], color = 'green', label = 'y')
    ax.plot(timey, columns_displacment[2], color = 'red', label = 'z')
    ax.set_xlabel('Time [sec]', fontsize = 12)
    ax.set_ylabel('Displacement [m]', fontsize = 12)
    ax.legend(loc='best', fancybox=True, framealpha = 0, ncol = 5, prop = {'size': 12})
    ax.set_title(number_to_place(ind+1)+' Route', fontsize = 16)
    
    plt.savefig(locy+'//Plots//Q2//LAB 1 '+str(ind+1)+'.svg', bbox_inches='tight', transparent=True)
    plt.close()
   
# Q3
    fig, ax = plt.subplots(figsize=(12,9))
    timey = np.linspace(0, len(columns_angles[0])/Hz, len(columns_angles[0]))
    for i in range(len(columns_angles)):
        ax.plot(timey, columns_angles[i], label = r'$\theta_{nume}$'.format(nume = i+1))

    ax.set_xlabel('Time [sec]', fontsize = 12)
    ax.set_ylabel(r'$\theta\ [\degree]$', fontsize = 12)
    ax.legend(bbox_to_anchor = (0.5, -0.05), loc='upper center', fancybox=True, framealpha = 0, ncol = 6, prop = {'size': 12})
    ax.set_title(r'$\theta$'+' vs Time '+ number_to_place(ind+1) + ' Route', fontsize = 16)

    plt.savefig(locy+'//Plots//Q3//LAB 1 Route_'+str(ind+1)+'.svg', bbox_inches='tight', transparent=True)
    plt.close()

plt.figure(figsize=(12,9))
ax = plt.axes(projection='3d')

ax.scatter(data_for_q4[0], data_for_q4[1], data_for_q4[2])
ax.set_xlabel('x [m]')
ax.set_ylabel('y [m]')
ax.set_zlabel('z [m]')
ax.set_title('EE workspace')

plt.savefig(locy+'//Plots//EE workspace.svg', transparent=True, bbox_inches='tight')
plt.close()
print('Done')