import numpy as np
import pickle
import os
import time
import glob
import matplotlib.pyplot as plt

# logdir_prefix = 'lab-01'
# data_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../data')

locy = r'C:\Users\Morten\OneDrive - mail.tau.ac.il\לימודים משותפים\מעבדות\שנה ד\סמסטר ב\מעבדה ברובוטיקה ובקרה של מערכות\מעבדה 1 - היכרות\נתונים'
data_path=(os.path.join(locy, 'data'))
snow_loc = r'C:\Users\Morten\OneDrive - mail.tau.ac.il\לימודים משותפים\מעבדות\שנה ד\סמסטר ב\מעבדה ברובוטיקה ובקרה של מערכות'

Hz = 30 #frequency [1/s]
data = []
data_for_q4 = []
for file in glob.glob(data_path + '/*/*.pkl'):
    with open(file, 'rb') as h:
        data.append(pickle.load(h))

for ind, section in enumerate(data):
    workin_mat = section[1]
    workin_mat2 = section[0]

    num_cols = len(workin_mat[0]) # get number of columns in matrix
    # extract columns using a loop
    columns_displacment = []
    for i in range(num_cols):
        columns_displacment.append([])
        if len(data_for_q4) < i+1:
            data_for_q4.append([])
        for row in workin_mat:
            columns_displacment[i].append(row[i])
            data_for_q4[i].append(row[i])
    
    
    workin_mat2 = section[0]
    num_cols2 = len(workin_mat2[0]) # get number of columns in matrix
    # extract columns using a loop
    columns_angles = []
    for i in range(num_cols2):
        columns_angles.append([])
        for row in workin_mat2:
            columns_angles[i].append(row[i])


#for fun plot 3d
    plt.figure(figsize=(12,9))
    ax = plt.axes(projection='3d')

    ax.plot3D(columns_displacment[0], columns_displacment[1], columns_displacment[2], markersize = 10)
    ax.text(columns_displacment[0][0], columns_displacment[1][0], columns_displacment[2][0], 'start', color='purple')
    ax.text(columns_displacment[0][-1], columns_displacment[1][-1], columns_displacment[2][-1], 'end', color='red')
    ax.set_xlabel('x [m]')
    ax.set_ylabel('y [m]')
    ax.set_zlabel('z [m]')
    ax.set_title(str(ind+1) + 'st Route')

    plt.savefig(locy+'//Plots//3d//LAB 1_' + str(ind+1) + '.svg', transparent=True)
    plt.close()


# 2) Plot x,y,z with respect to time
    for indy, elem in enumerate(columns_displacment):
        if indy == 0:
            titled_definder = 'xdata'
            cator = 'x'
        if indy == 1:
            titled_definder = 'ydata'
            cator = 'y'
        if indy == 2:
            titled_definder = 'zdata'
            cator = 'z'
        
        
        fig, ax = plt.subplots(figsize=(12,9))
        x_to_plot = np.linspace(0, len(elem)/Hz, len(elem))
        y_to_plot = elem

        borders = [min(x_to_plot)*1, max(x_to_plot)*1, min(y_to_plot)*1, max(y_to_plot)*1]
        ax.imshow(plt.imread(snow_loc+'//Snow.jpg'), extent = borders, aspect='auto')

        ax.plot(x_to_plot, y_to_plot, color = 'yellow', label = 'Measured')
        ax.set_xlabel('Time [s]', fontsize = 12)
        ax.set_ylabel('Displacement '+cator+' [m]', fontsize = 12)
        # ax.legend(loc='best', fancybox=True, framealpha = 0, ncol = 5, prop = {'size': 12})
        ax.set_title(titled_definder+' '+ str(ind+1) + 'st Route', fontsize = 16)

        plt.savefig(locy+'//Plots'+'//'+titled_definder+'//LAB 1 '+str(ind+1)+cator+'.svg', transparent=True)
        plt.close()
   
# Q3
    for indy, elem in enumerate(columns_angles):
        x_to_plot = np.linspace(0, len(elem)/Hz, len(elem))
        y_to_plot = elem
        fig, ax = plt.subplots(figsize=(12,9))

        borders = [min(x_to_plot)*1, max(x_to_plot)*1, min(y_to_plot)*1, max(y_to_plot)*1]
        ax.imshow(plt.imread(snow_loc+'//Snow.jpg'), extent = borders, aspect='auto')

        ax.plot(x_to_plot, y_to_plot, color = 'yellow', label = 'Measured')
        ax.set_xlabel('Time [s]', fontsize = 12)
        ax.set_ylabel(r'$\theta_{nume} [\degree]$'.format(nume = indy+1), fontsize = 12)
        # ax.legend(loc='best', fancybox=True, framealpha = 0, ncol = 5, prop = {'size': 12})
        ax.set_title(r'$\theta_{nume}$'.format(nume = indy+1)+' vs Time '+str(ind+1) + 'st Route', fontsize = 16)

        plt.savefig(locy+'//Plots//angles//Route'+str(ind+1)+'//LAB 1 theta_'+str(indy+1)+'.svg', transparent=True)
        plt.close()

plt.figure(figsize=(12,9))
ax = plt.axes(projection='3d')

ax.scatter(data_for_q4[0], data_for_q4[1], data_for_q4[2])
ax.set_xlabel('x [m]')
ax.set_ylabel('y [m]')
ax.set_zlabel('z [m]')
ax.set_title('Question 4 workspace')

plt.savefig(locy+'//Plots//Question 4 workspace.svg', transparent=True)
plt.close()