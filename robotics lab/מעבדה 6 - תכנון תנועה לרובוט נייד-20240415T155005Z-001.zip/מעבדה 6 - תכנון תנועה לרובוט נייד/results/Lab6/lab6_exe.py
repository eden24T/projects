"""
All right reserved to  Itamar Mishani and Osher Azulay
imishani@gmail.com, osherazulay@mail.tau.ac.il
"""

import matplotlib.pyplot as plt
import math
from scipy.spatial.transform import Rotation as R
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../common/car"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../common/robot"))
sys.path.insert(0, r'../common/NatNetSDK/Samples/PythonClient/')

import numpy as np
from Labs.common.car.car_control import Controller
from track_cars import Tracker

import cv2
from lab6_car import planner, steering_angle
# from Lab06_student_GAS import planner, steering_angle
import time

s = time.time()


def save(data_to_save, prefix='4'):
    logdir_prefix = f'lab-0{prefix}'
    data_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), f'../../Lab{prefix}/data')

    if not (os.path.exists(data_path)):
        os.makedirs(data_path)

    logdir = logdir_prefix + '_' + time.strftime("%d-%m-%Y_%H-%M-%S")
    logdir = os.path.join(data_path, logdir)
    if not (os.path.exists(logdir)):
        os.makedirs(logdir)

    print("\n\n\nLOGGING TO: ", logdir, "\n\n\n")

    import pickle
    with open(logdir + '/data' + '.pkl', 'wb') as h:
        pickle.dump(data_to_save, h)


def calc_motor_command(angle):
    x = angle / 180.
    if x <= 0:
        right = 1.
        left = -2 * x + 1
    else:
        left = 1.
        right = 2 * x + 1
    left = math.copysign(1, left) - left * 0.5
    right = math.copysign(1, right) - right * 0.5
    return left, right


def convert_next_to_car(homo_car, next_goal):
    try:

        v_next, phi = steering_angle(homo_car, np.array(next_goal))
        curr_x, curr_y = homo_car[0, 3], homo_car[1, 3]

        plt.plot(curr_x, curr_y, 'ko', ms=2., alpha=0.4)
        plt.draw()

        return phi, v_next, (curr_x, curr_y)

    except:

        print('Error! Cannot detect frames')
        cntrlr.motor_command(1., 1.)


if __name__ == "__main__":

    # TODO: Fill here the tracker information
    axes_origin_ID = 1
    car_ID_to_tracker = 2
    goal_ID = 7

    tracker = Tracker(axes_origin_ID, car_ID_to_tracker, goal_ID)
    time.sleep(2)

    # TODO: Fill here the car information
    car_ID_to_controller = 3
    address = "192.168.255.249"

    cntrlr = Controller(car_ID_to_controller, address)

    # Init connection with the car
    cntrlr.connect()
    time.sleep(1)
    cntrlr.motor_command(1., 1.)  # Don't move!

    # Get the obstacle position
    obs_list = [np.hstack((tracker.obstacles[i][:2, 3], 0.1)).tolist() for i in tracker.obstacles.keys()]

    input(f'Planning between {tracker.car_pose[:2, 3].tolist()} to {tracker.goal_pose[:2, 3].tolist()} \n'
          f'press Enter to continue')

    # Calc plan from car pose to goal pose
    path_ = planner(tracker.car_pose[:2, 3].tolist(),
                    tracker.goal_pose[:2, 3].tolist(),
                    obs_list)

    # Apply CL plan tracking

    executed_path = []

    while cntrlr.Connected:

        tolerance = 0.08  # goal tolerance, may need to be modified
        i = 1

        for next_goal in path_:

            # if next_goal == path_[-1]: tolerance *= 2

            print(f'Attempting to reach point: {i} of {len(path_)}')
            next_ = [10e2, 10e2]

            while np.linalg.norm(next_[:2]) > tolerance:

                try:
                    phi, next_, curr = convert_next_to_car(tracker.car_pose, next_goal)
                    executed_path.append(list(curr))

                    print(f' Phi: {round(phi)}, error: {next_[:2]} Distance: {np.linalg.norm(next_[:2])}')
                except:
                    continue

                if np.linalg.norm(next_[:2]) <= tolerance:
                    cntrlr.motor_command(1, 1)
                    continue

                left, right = calc_motor_command(phi)
                cntrlr.motor_command(-left, -right)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
            i += 1
            cntrlr.motor_command(1, 1)

        print("\n\nReached goal!! \n")
        cntrlr.motor_command(1., 1.)

        cv2.destroyAllWindows()
        if input('Save data? (y,n)') == 'y':
            save([path_, executed_path], prefix='6')
            print('Saved data as list of size 2 where first element is planned path and second is executed path!')
        sys.exit(0)
