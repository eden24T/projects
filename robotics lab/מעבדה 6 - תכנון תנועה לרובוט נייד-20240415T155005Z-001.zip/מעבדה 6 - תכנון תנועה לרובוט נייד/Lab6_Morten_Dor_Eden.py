import numpy as np
import pickle
import os
import glob
import matplotlib.pyplot as plt
from matplotlib import patches
import Morten_Robotics as MR


locy = r'C:\Users\Morten\OneDrive - mail.tau.ac.il\לימודים משותפים\מעבדות\שנה ד\סמסטר ב\מעבדה ברובוטיקה ובקרה של מערכות\מעבדה 6 - תכנון תנועה לרובוט נייד'

data_path = os.path.join(locy, 'data')
MR.create_directory(locy+'//Plots')

data = []
for file in glob.glob(data_path + '/*/*.pkl'):
    with open(file, 'rb') as h:
        data.append(pickle.load(h))

obsicle_loc = [[[-0.4, 0.9], [0.1, 1.2]], [[-0.4, 0.85], [-0.23, 1.35]], [[-0.4, 0.7], [0.2, 0.8]]]
obsicle_radius = 0.1

#plot
for ind, section in enumerate(data):
    xyzz = MR.colum_extractor(section[0])
    xyzz2 = MR.colum_extractor(section[1])
    
    # Start Plotiing
    fig = plt.figure(figsize=(12,9))
    ax = fig.add_subplot()
    
    ax.scatter(xyzz[0][0], xyzz[1][0], color = 'red')
    ax.scatter(xyzz2[0][0], xyzz2[1][0], color = 'red')

    ax.scatter(xyzz[0][-1], xyzz[1][-1], color = 'blue')
    ax.scatter(xyzz2[0][-1], xyzz2[1][-1], color = 'blue')

    on_now = obsicle_loc[ind]
    for elelele in on_now:
        circle1 = patches.Circle((elelele[0], elelele[1]), radius=obsicle_radius, color='green')
        ax.add_patch(circle1)
    
    ax.plot(xyzz[0], xyzz[1], label = 'Real Path')
    ax.plot(xyzz2[0], xyzz2[1], label = 'Planned Path')

    ax.legend(bbox_to_anchor = (0.5, -0.07), loc='upper center', fancybox=True, framealpha = 0, ncol = 6, prop = {'size': 12})

    ax.set_xlabel('x [m]', fontsize = 12)
    ax.set_ylabel('y [m]', fontsize = 12)
    ax.axis('equal')
 
    #title and other shit
    ax.set_title(MR.number_to_place(ind+1)+' Route', fontsize = 16)
    plt.savefig(locy+'//Plots//LAB 6 Route '+str(ind+1)+'.svg', bbox_inches='tight', transparent=True)

    if True:
        plt.show()
    plt.close()

    xyzz = np.array(xyzz)
    xyzz2 = np.array(xyzz2)

    for_x = MR.closest_vec(xyzz[0], xyzz2[0])
    for_y = MR.closest_vec(xyzz[1], xyzz2[1])
    averageer_error_x = 100*np.abs(np.average((for_x-xyzz[0])/np.maximum(for_x, xyzz[0])))
    averageer_error_y = 100*np.abs(np.average((for_y-xyzz[1])/np.maximum(for_y, xyzz[1])))
    print('The average error is: {} %'.format(np.maximum(averageer_error_x, averageer_error_y)))