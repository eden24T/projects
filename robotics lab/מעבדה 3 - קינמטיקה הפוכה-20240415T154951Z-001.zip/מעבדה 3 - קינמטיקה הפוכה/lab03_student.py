import numpy as np
from sympy import *
from scipy.spatial.transform import Rotation

alpha1, alpha2, alpha3, alpha4, alpha5, alpha6 = symbols('alpha1:7')
a1, a2, a3, a4, a5, a6 = symbols('a1:7')
d1, d2, d3, d4, d5, d6 = symbols('d1:7')
q1, q2, q3, q4, q5, q6 = symbols('q1:7')

'''
Hint1: you should use your functions from the previous lab
Hint2: using sympy is easier for debugging, but not mandatory
'''

def A0_i_gas(index):
    """
    In- intergrger (index)
    Out- 4X4 homgogenues trasformation Matrix (A^0_index)
    """
    table = set_dh_table()
    listy = [dh(table[alpha1], table[a1], table[d1], table[q1]),
             dh(table[alpha2], table[a2], table[d2], table[q2]),
             dh(table[alpha3], table[a3], table[d3], table[q3]),
             dh(table[alpha4], table[a4], table[d4], table[q4]),
             dh(table[alpha5], table[a5], table[d5], table[q5]),
             dh(table[alpha6], table[a6], table[d6], table[q6])]
    
    # Tes = Matrix([[0, -1, 0, 0], [1, 0, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])  # mandatory
    # T = T_01 * T_12 * T_23 * T_34 * T_45 * T_56 * Tes

    A = eye(4)
    for i in range(1, index + 1):
        A=A*listy[i-1]
    return A



def set_dh_table():
    """

    Returns: dictionary

    Important: all length arguments in [m]
               all angles argument in [radians]

    """

    dh_subs_dict = {alpha1: pi / 2, a1: 0, d1: (128.5 + 115) / 1000, q1: q1,
                    alpha2: pi, a2: 0.28, d2: 0.03, q2: q2 + pi / 2,
                    alpha3: pi / 2, a3: 0, d3: 0.02, q3: q3 + pi / 2,
                    alpha4: pi / 2, a4: 0, d4: 0.245, q4: q4 + pi / 2,
                    alpha5: pi / 2, a5: 0, d5: 0.057, q5: q5 + pi,
                    alpha6: 0, a6: 0, d6: 0.235, q6: q6 + pi / 2}

    return dh_subs_dict


def dh(alpha, a, d, theta):
    """
    Args:
        alpha: torsion angle
        a: distance
        d: translation
        theta: rotation angle

    Returns: Homogeneous DH matrix

    Important note: use sympy cos/sin arguments instead of math/numpy versions.
    i.e: cos(theta) \ sin(theta)

    """
    DH = Matrix([[cos(theta), -sin(theta) * cos(alpha), sin(theta) * sin(alpha), a * cos(theta)],
                 [sin(theta), cos(theta) * cos(alpha), -cos(theta) * sin(alpha), a * sin(theta)],
                 [0, sin(alpha), cos(alpha), d], [0, 0, 0, 1]]
                )
    return DH




def Jacobian(Q):
    '''
    Args:
        Q: joint configuration list [1,6]
    Returns:
        Full Jacobian matrix [6,6]
    '''

    Jacoy = Matrix([[JL1,JL2,JL3,JL4,JL5,JL6], [JA1,JA2,JA3,JA4,JA5,JA6]])

    Jacoys = Jacoy.subs([(q1, Q[0]), (q2, Q[1]), (q3, Q[2]), (q4, Q[3]), (q5, Q[4]), (q6, Q[5])])
    return np.array(Jacoys.evalf()).astype(np.float64)


def LinearJacobian(Q):
    '''

    Args:
        Q: joint configuration list [1,6]

    Returns:
        Linear part of the Jacobian matrix [3,6]
    '''

    Jacoy = Matrix([[JL1,JL2,JL3,JL4,JL5,JL6]])

    Jacoys = Jacoy.subs([(q1, Q[0]), (q2, Q[1]), (q3, Q[2]), (q4, Q[3]), (q5, Q[4]), (q6, Q[5])])
    return np.array(Jacoys.evalf()).astype(np.float64)

def FK(theta_list):
    """
    Args:
        theta_list: joint angle vector ---> list [1,6]
    Returns:
        End effector homogeneous matrix --> Matrix((4, 4))

    Hints:
        - we have added a sympy implementation with missing parts, u dont have to use the same method.
        - chain 'Tes' to T_06 at the end.
    """
    table = set_dh_table()

    T_01 = dh(table[alpha1], table[a1], table[d1], table[q1])
    T_12 = dh(table[alpha2], table[a2], table[d2], table[q2])
    T_23 = dh(table[alpha3], table[a3], table[d3], table[q3])
    T_34 = dh(table[alpha4], table[a4], table[d4], table[q4])
    T_45 = dh(table[alpha5], table[a5], table[d5], table[q5])
    T_56 = dh(table[alpha6], table[a6], table[d6], table[q6])
    Tes = Matrix([[0, -1, 0, 0], [1, 0, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])  # mandatory
    T = T_01 * T_12 * T_23 * T_34 * T_45 * T_56 * Tes

    ''' fill angles to dict for sympy calculations'''

    theta_dict = {}
    keys = [q1, q2, q3, q4, q5, q6]
    for i in range(len(theta_list)):
        theta_dict[keys[i]] = theta_list[i]
    ''' 
    homogeneous transformation matrix from base_link to end_effector [type: numeric matrix] 
    because we are using sympy, we have to use evalf.
    '''
    T_0G_eval = T.evalf(subs=theta_dict, chop=True, maxn=4)

    return T_0G_eval



def IK_NR_position(guess, target):
    '''
    Args:
        guess: initial angle guess list [1,6] {q1-6}
        target: task configuration tcp position [1,3] {x,y,z}

    Returns:
        Q* - joint configuration angles [1, 6]
    '''

    epsilon = 0.05
    lambday = 0.5
    targety = np.array(target)
    locy = np.array(FK(guess)[:,-1][:-1])
    error = targety-locy
    error = error.astype(np.float64)

    theta_0 = guess
    while np.linalg.norm(error) > epsilon:
        Lin_gas = np.matmul((np.transpose(LinearJacobian(theta_0))), np.transpose(error))
        theta_0 = theta_0 + lambday*Lin_gas[0]
        locy = np.array(FK(theta_0)[:,-1][:-1])
        error = targety-locy
        error = error.astype(np.float64)
        print(np.linalg.norm(error))

    return theta_0


'raw data'
d01 = A0_i_gas(1).col(-1)
d01.row_del(-1)
d02 = A0_i_gas(2).col(-1)
d02.row_del(-1)
d03 = A0_i_gas(3).col(-1)
d03.row_del(-1)
d04 = A0_i_gas(4).col(-1)
d04.row_del(-1)
d05 = A0_i_gas(5).col(-1)
d05.row_del(-1)
Tes = Matrix([[0, -1, 0, 0], [1, 0, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])  # mandatory
d06 = (A0_i_gas(6)*Tes).col(-1)
d06.row_del(-1)


R01 = A0_i_gas(1)
R01.row_del(-1)
R01.col_del(-1)
R02 = A0_i_gas(2)
R02.row_del(-1)
R02.col_del(-1)
R03 = A0_i_gas(3)
R03.row_del(-1)
R03.col_del(-1)
R04 = A0_i_gas(4)
R04.row_del(-1)
R04.col_del(-1)
R05 = A0_i_gas(5)
R05.row_del(-1)
R05.col_del(-1)


cool_vec_31 = Matrix([0,0,1])

JL1 = cool_vec_31.cross(d06)
JL2 = (R01*cool_vec_31).cross(d06-d01)
JL3 = (R02*cool_vec_31).cross(d06-d02)
JL4 = (R03*cool_vec_31).cross(d06-d03)
JL5 = (R04*cool_vec_31).cross(d06-d04)
JL6 = (R05*cool_vec_31).cross(d06-d05)

JA1 = cool_vec_31
JA2 = (R01*cool_vec_31)
JA3 = (R02*cool_vec_31)
JA4 = (R03*cool_vec_31)
JA5 = (R04*cool_vec_31)
JA6 = (R05*cool_vec_31)

print(IK_NR_position([0,0,0,0,0.5,0],[0.05,-0.17,1]))