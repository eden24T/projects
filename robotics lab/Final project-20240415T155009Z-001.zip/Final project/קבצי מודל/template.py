import numpy as np
import matplotlib.pyplot as plt

from WheeledCar import WheeledCar

#### These definitions should not be moved from here. Will be modified by the instructors!!! ###
p_g = np.array([0.40073523, 0.70651546]) # Set <x_g, y_g> goal position
x_r = np.array([2, 2.2 , np.deg2rad(110)]) # Set initial pose of the robot: <x_r, y_r, phi_r>
O = np.array([[2, 0.8], [1.2, 1.9], [0.6, 1.6], [0.8, 0.3]]) # Set positions of obstacles [p_1, p_2, p_3, p_4]

### Start your code from here ###

# Example:

W = WheeledCar(x = x_r, goal = p_g, Obs = O) # Initiate simulation with x0, goak and Obs

# Get status of car - use these parameters in your planning
x_r, p_g, p_1, p_2, p_3, p_4 = W.field_status()

# Example of tracking a naive fixed path - NOT motion planning!!!
S = np.linspace(0, 1, 10)
mid = np.array([1.5, 0.6])
path = []
for s in S:
    path.append(x_r[:2] + s * (mid-x_r[:2]))
for s in S:
    path.append(mid + s * (p_g - mid))
path = np.array(path)

# Run the robot along the planned path
W.run(path)
