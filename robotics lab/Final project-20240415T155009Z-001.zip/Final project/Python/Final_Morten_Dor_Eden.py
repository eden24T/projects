import numpy as np
import matplotlib.pyplot as plt
import visibility_road_map_1 as vb
import WheeledCar as Wh

'''
THIS VERSION IS STABLE
'''

do_plot = False #A boolean flag indicating whether to plot the results
x_r = np.array([0.1, 0.1, np.deg2rad(12)]) #from template, Set initial pose of the robot: <x_r, y_r, phi_r>
p_g = np.array([2.1, 2.3]) # Set <x_g, y_g> goal position
O = np.array([[0.2, 1.2],[1.9, 0.8], [0.8, 1.5],[2.15, 1.8]]) #from template, Set positions of obstacles [p_1, p_2, p_3, p_4]

# Parameters
cart_width = 0.12 #[m] cart width
squar_deafult_lenght = 0.2 #[m] #Default radius for obstacles
expand_distance = 0.15 #[m]
point_per_meter = 5
Safe_side_factor = 1.2
obstacles = []


def angels_to_follow(robot_loc, route):
    '''
    robot_loc is list of [x,y,angle] in meter and rad
    route is list of point is space, for expample [[0.1, 0.1], [0.2, 0.2]]
    '''
    angle = robot_loc[2]
    to_return = []

    for i in range(len(route)-1):
        if i == 0:
            to_return.append(np.arctan2(route[i+1][1]-route[i][1], route[i+1][0]-route[i][0])-angle)
        else:
            to_return.append(np.arctan2(route[i+1][1]-route[i][1], route[i+1][0]-route[i][0])-np.arctan2(route[i][1]-route[i-1][1], route[i][0]-route[i-1][0]))
    to_return.append(to_return[-1])
    return to_return

def make_circle_list(the_x, the_y, the_radius=squar_deafult_lenght, pointtss=5, starting_angle = 0):
    '''
    starting_angle in dergrees
    the_x, the_y - are the coordinates of the center of the shape
    the_radius in [m]
    pointtss=5 for making a square shape

    '''
    thetaa = np.linspace(np.radians(45)+np.radians(starting_angle),
                          np.radians(45)+2*np.pi+np.radians(starting_angle), pointtss)
    y_list = the_y + the_radius*np.sin(thetaa)
    x_list = the_x + the_radius*np.cos(thetaa)
    return x_list.tolist(), y_list.tolist()

#extende the path
def path_extender(points, point_per_meter = 5, angle_const = True):
    """
    Input:
    points- 2 dim array of points.
    Output:
    new path with the points in it.
    """
    new_points = []
    for i in range(len(points)-1):
        p1 = points[i]
        p2 = points[i+1]
        distancey = np.linalg.norm(p2[:-1]-p1[:-1])
        numbers_of_points = int(distancey * point_per_meter)+1
        if distancey<=0.5:
            numbers_of_points = numbers_of_points+1
        for j in range(numbers_of_points):
            holder = p1 + (p2-p1)*j/numbers_of_points
            if angle_const:
                holder[-1] = p1[-1]
            new_points.append(holder)
        if i == len(points)-2:
            new_points.append(p2)
    return np.array(new_points)

#making sure cart can go throu
def cart_clearence(Obs_loc, Safe_side = Safe_side_factor):
    for index in range(len(Obs_loc)):
        current = np.array(Obs_loc[index])

        wall=np.array([0,2.4,0,2.4])
        for dor in range(len(wall)):
            if dor<=1:
                if np.linalg.norm(current[0]-wall[dor]) <= Safe_side*cart_width + squar_deafult_lenght:
                    a12, b12 = [wall[dor], Obs_loc[index][0]], [Obs_loc[index][-1],Obs_loc[index][-1]]
                    obstacles.append(vb.ObstaclePolygon(a12, b12))
            else:
                if np.linalg.norm(current[1]-wall[dor]) <= Safe_side*cart_width + squar_deafult_lenght:
                    a12, b12 = [Obs_loc[index][0], Obs_loc[index][0]], [wall[dor], Obs_loc[index][-1]]
                    obstacles.append(vb.ObstaclePolygon(a12, b12))

        for j in range(index, len(Obs_loc)):
            runner = np.array(Obs_loc[j])

            if np.linalg.norm(current-runner) <= Safe_side*cart_width + 2*squar_deafult_lenght:
                a12, b12 = [Obs_loc[index][0], Obs_loc[j][0]], [Obs_loc[index][1], Obs_loc[j][1]]
                obstacles.append(vb.ObstaclePolygon(a12, b12))


#making the virtual walls
for i in range(0, len(O), 2):
    a1, b1 = O[i], O[i+1]
    obstacles.append(vb.ObstaclePolygon([a1[0], b1[0]],[a1[1], b1[1]]))

#creating boundries, DO NOT DELETE THIS
obstacles.append(vb.ObstaclePolygon([0, 2.4, 2.4, 0], [0, 0, 2.4, 2.4]))


#Always run this for making sure cart can go throu good for 2 or more obsticle that are too close.
cart_clearence(O)

#making the square obsticles
for el in O:
    a1, b1 = make_circle_list(el[0], el[1])
    obstacles.append(vb.ObstaclePolygon(a1,b1))


#plotting
if do_plot:
    plt.plot(x_r[0], x_r[1], "or")
    plt.plot(p_g[0], p_g[1], "ob")
    for ob in obstacles:
        ob.plot()
    plt.axis("equal")
    # plt.pause(1.0)

#computing route
al = vb.VisibilityRoadMap(expand_distance, do_plot)
x_planned, y_planned = al.planning(x_r[0], x_r[1], p_g[0], p_g[1], obstacles) #This performs the visibility roadmap algorithm and returns the x and y coordinates of the planned path.


#plotting chosen route
if do_plot:
    plt.plot(x_planned, y_planned, "-r")
    plt.pause(0.1)
    plt.show()
plt.close()

#creating route:
the_route_is = []
for i in range(len(x_planned)):
    the_route_is.append([x_planned[i], y_planned[i]])

angles=angels_to_follow(x_r, the_route_is)
for elem in range(len(the_route_is)):
    the_route_is[elem].append(angles[elem])

the_route_is = np.array(the_route_is)
path = path_extender(the_route_is, point_per_meter, True)


W=Wh.WheeledCar(x = x_r, goal = p_g, Obs = O) # Initiate simulation with x0, goak and Obs

# Get status of car - use these parameters in your planning
x_r, p_g, p_1, p_2, p_3, p_4 = W.field_status()

W.run(path)