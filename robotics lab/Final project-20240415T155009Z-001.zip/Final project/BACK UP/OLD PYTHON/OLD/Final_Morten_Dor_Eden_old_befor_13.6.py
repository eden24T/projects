import numpy as np
import matplotlib.pyplot as plt
import visibility_road_map_1 as vb
import pygame
#import WheeledCar.py as Wh


### Data from template ###

x_r = np.array([2, 2.2 , np.deg2rad(110)]) #from template, Set initial pose of the robot: <x_r, y_r, phi_r>
p_g = np.array([0.40073523, 0.70651546]) # Set <x_g, y_g> goal position
O = np.array([[2, 0.8], [1.2, 1.9], [0.6, 1.6], [0.8, 0.3]]) #from template, Set positions of obstacles [p_1, p_2, p_3, p_4]

#Convert data from template to our units of the code
do_plot = True #A boolean flag indicating whether to plot the results
roootz = True #motivation sound
cart_width = 0.2 #[m] cart width
start_x, start_y, goal_x, goal_y =x_r[0],x_r[1],p_g[0],p_g[1]  #[m, SI IS ONLY I KNOW]
circle_deafult_radius = 0.2 #[m] #Default radius for obstacles
expand_distance = 0.15 #[m]
obstacles_locations =O.tolist()
obstacles = []

def make_circle_list(the_x, the_y, the_radius=circle_deafult_radius, pointtss=5, starting_angle = 0):
    '''
    starting_angle in dergrees
    the_x, the_y - are the coordinates of the center of the shape
    the_radius in [m]

    '''
    thetaa = np.linspace(np.radians(45)+np.radians(starting_angle),
                          np.radians(45)+2*np.pi+np.radians(starting_angle), pointtss)
    y_list = the_y + the_radius*np.sin(thetaa)
    x_list = the_x + the_radius*np.cos(thetaa)
    return x_list.tolist(), y_list.tolist()

def creating_walls(xy_first, xy_last, wall_width = 1/(2*1000)):
    '''
    This function takes two sets of x and y coordinates (of two obstacles)
    and creates a list of x coordinates and a list of y coordinates for the walls
    surrounding the given coordinates. The walls are represented as a rectangle with a small thickness.
    '''
    return [xy_first[0]-wall_width, 
            xy_first[0]+wall_width, 
            xy_last[0]+wall_width, 
            xy_last[0]-wall_width],[xy_first[1],
                                xy_first[1],
                                 xy_last[1],
                                 xy_last[1]]


#making sure cart can go throu
def cart_clearence(obstacles_locations=obstacles_locations):
    for index in range(len(obstacles_locations)):
        current = np.array(obstacles_locations[index])
        for j in range(index, len(obstacles_locations)):
            runner = np.array(obstacles_locations[j])

            if np.linalg.norm(current-runner) <= 1.5*cart_width + 2*circle_deafult_radius:
                a12, b12 = creating_walls(obstacles_locations[index], obstacles_locations[j])
                obstacles.append(vb.ObstaclePolygon(a12, b12))

            # if ((abs(runner[0]-current[0])-2*circle_deafult_radius <= 1.5*cart_width) and
            #      (abs(runner[1]-current[1])-2*circle_deafult_radius <= 1.5*cart_width)):
            #     a12, b12 = creating_walls(runner, current)
            #     obstacles.append(vb.ObstaclePolygon(a12, b12))

#run this only if 2 or more obsticle are too close. making sure cart can go throu 
cart_clearence()

#making the virtual walls
for i in range(0, len(obstacles_locations), 2):
    a1, b1 = obstacles_locations[i], obstacles_locations[i+1]
    a12, b12 = creating_walls(a1, b1)
    obstacles.append(vb.ObstaclePolygon(a12,b12))

#creating boundries
obstacles.append(vb.ObstaclePolygon([0, 2.4, 2.4, 0], [0, 0, 2.4, 2.4]))

#making the square obsticles
for el in obstacles_locations:
    a1, b1 = make_circle_list(el[0], el[1])
    obstacles.append(vb.ObstaclePolygon(a1,b1))

#plotting
if do_plot:
    plt.plot(start_x, start_y, "or")
    plt.plot(goal_x, goal_y, "ob")
    for ob in obstacles:
        ob.plot()
    plt.axis("equal")
    plt.pause(1.0)

#computing route
al = vb.VisibilityRoadMap(expand_distance, do_plot)
x_planned, y_planned = al.planning(start_x, start_y, goal_x, goal_y, obstacles) #This performs the visibility roadmap algorithm and returns the x and y coordinates of the planned path.
print(x_planned, y_planned) #instead of printing we should send x_planned, y_planned to the robot instead.

#plotting chosen route
if do_plot:
    plt.plot(x_planned, y_planned, "-r")
    plt.pause(0.1)
    plt.show()


### motivation lines###
if roootz:
    pygame.init()
    ruuner_path = 'C:/Users/selic/OneDrive - mail.tau.ac.il/הנדסה מכנית- מסונכרן בענן/run.wav'
    # ruuner_path = r'C:\Users\Morten\OneDrive - mail.tau.ac.il\לימודים משותפים\מעבדות\שנה ד\סמסטר ב\מעבדה ברובוטיקה ובקרה של מערכות\Final project\Python\run.wav'
    ###change to your path of מעבדה ברובוטיקה ובקרה של מערכות###
    pygame.mixer.music.load(ruuner_path)
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        pygame.time.wait(1000)  # Adjust the delay value (in milliseconds) as needed
    pygame.quit()

### END of motivation lines###
