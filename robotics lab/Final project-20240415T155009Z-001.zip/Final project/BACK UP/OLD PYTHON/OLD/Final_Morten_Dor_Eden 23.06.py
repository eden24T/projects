import numpy as np
import matplotlib.pyplot as plt
import visibility_road_map_1 as vb
import WheeledCar as Wh

do_plot = False #A boolean flag indicating whether to plot the results

x_r = np.array([0.5, 1, np.deg2rad(0)]) #from template, Set initial pose of the robot: <x_r, y_r, phi_r>
p_g = np.array([2, 2.1]) # Set <x_g, y_g> goal position
O = np.array([[1, 1], [1.2, 1.9], [0.5, 0.5], [1.2, 0.3]]) #from template, Set positions of obstacles [p_1, p_2, p_3, p_4]

robot_angle=x_r[2] #deg
#Convert data from template to our units of the code
cart_width = 0.25 #[m] cart width
start_x, start_y, goal_x, goal_y =x_r[0],x_r[1],p_g[0],p_g[1]  #[m, SI IS ONLY I KNOW]
squar_deafult_lenght = 0.2 #[m] #Default radius for obstacles
expand_distance = 0.15 #[m]
obstacles_locations =O.tolist()
obstacles = []


def angels_to_follow(robot_loc, route):
    '''
    robot_loc is list of [x,y,angle] in meter and rad
    route is list of point is space, for expample [[0.1, 0.1], [0.2, 0.2]]
    '''
    angle = robot_loc[2]
    to_return = []

    for i in range(len(route)-1):
        if i == 0:
            to_return.append(np.arctan2(route[i+1][1]-route[i][1], route[i+1][0]-route[i][0])-angle)
        else:
            to_return.append(np.arctan2(route[i+1][1]-route[i][1], route[i+1][0]-route[i][0])-np.arctan2(route[i][1]-route[i-1][1], route[i][0]-route[i-1][0]))
    to_return.append(to_return[-1])
    return to_return

def make_circle_list(the_x, the_y, the_radius=squar_deafult_lenght, pointtss=5, starting_angle = 0):
    '''
    starting_angle in dergrees
    the_x, the_y - are the coordinates of the center of the shape
    the_radius in [m]
    pointtss=5 for making a square shape

    '''
    thetaa = np.linspace(np.radians(45)+np.radians(starting_angle),
                          np.radians(45)+2*np.pi+np.radians(starting_angle), pointtss)
    y_list = the_y + the_radius*np.sin(thetaa)
    x_list = the_x + the_radius*np.cos(thetaa)
    return x_list.tolist(), y_list.tolist()

#extende the path
def path_extender(points, number_of_point = 4, angle_const = True):
    '''
    recives np.array of points for expamle [[1, 1, 1.5], [2,2,2.5]]
    rutunes the path between points
    '''
    n = len(points)
    path = np.zeros((number_of_point*(n-1), 3))  # Initialize the path array
    
    for i in range(n-1):
        start_point = points[i]
        end_point = points[i+1]
        
        # Generate m equally spaced points between start_point and end_point
        for j in range(number_of_point):
            t = j / (number_of_point-1)  # Parameterize the path from 0 to 1
            interpolated_point = start_point + t * (end_point - start_point)
            if angle_const:
                interpolated_point[-1]=start_point[-1]
            path[i*number_of_point + j] = interpolated_point
    return path

#making sure cart can go throu
def cart_clearence(obstacles_locations=obstacles_locations):
    for index in range(len(obstacles_locations)):
        current = np.array(obstacles_locations[index])
        for j in range(index, len(obstacles_locations)):
            runner = np.array(obstacles_locations[j])

            if np.linalg.norm(current-runner) <= 1.5*cart_width + 2*squar_deafult_lenght:
                # a12, b12 = creating_walls(obstacles_locations[index], obstacles_locations[j])
                a12, b12 = [obstacles_locations[index][0], obstacles_locations[j][0]], [obstacles_locations[index][1], obstacles_locations[j][1]]
                obstacles.append(vb.ObstaclePolygon(a12, b12))

#run this only if 2 or more obsticle are too close. making sure cart can go throu 
cart_clearence()

#making the virtual walls
for i in range(0, len(obstacles_locations), 2):
    a1, b1 = obstacles_locations[i], obstacles_locations[i+1]
    obstacles.append(vb.ObstaclePolygon([a1[0], b1[0]],[a1[1], b1[1]]))

#creating boundries
obstacles.append(vb.ObstaclePolygon([0, 2.4, 2.4, 0], [0, 0, 2.4, 2.4]))

#making the square obsticles
for el in obstacles_locations:
    a1, b1 = make_circle_list(el[0], el[1])
    obstacles.append(vb.ObstaclePolygon(a1,b1))


#plotting
if do_plot:
    plt.plot(start_x, start_y, "or")
    plt.plot(goal_x, goal_y, "ob")
    for ob in obstacles:
        ob.plot()
    plt.axis("equal")
    plt.pause(1.0)

#computing route
al = vb.VisibilityRoadMap(expand_distance, do_plot)
x_planned, y_planned = al.planning(start_x, start_y, goal_x, goal_y, obstacles) #This performs the visibility roadmap algorithm and returns the x and y coordinates of the planned path.


#plotting chosen route
if do_plot:
    plt.plot(x_planned, y_planned, "-r")
    plt.pause(0.1)
    plt.show()
plt.close()

#creating route:
the_route_is = []
for i in range(len(x_planned)):
    the_route_is.append([x_planned[i], y_planned[i]])

angles=angels_to_follow(x_r, the_route_is)
for elem in range(len(the_route_is)):
    the_route_is[elem].append(angles[elem])

the_route_is = np.array(the_route_is)
path = path_extender(the_route_is, 4, True)


W=Wh.WheeledCar(x = x_r, goal = p_g, Obs = O) # Initiate simulation with x0, goak and Obs

# Get status of car - use these parameters in your planning
x_r, p_g, p_1, p_2, p_3, p_4 = W.field_status()

W.run(path)


#import pygame


### motivation lines###
# roootz = False #motivation sound
# if roootz:
#     pygame.init()
#     ruuner_path = 'C:/Users/selic/OneDrive - mail.tau.ac.il/הנדסה מכנית- מסונכרן בענן/run.wav'
#   #  ruuner_path = r'C:\Users\Morten\OneDrive - mail.tau.ac.il\לימודים משותפים\מעבדות\שנה ד\סמסטר ב\מעבדה ברובוטיקה ובקרה של מערכות\run.wav'
#     # 'C:\Users\Morten\OneDrive - mail.tau.ac.il\לימודים משותפים\מעבדות\שנה ד\סמסטר ב\מעבדה ברובוטיקה ובקרה של מערכות\Final project\Python\run.wav'
#     ###change to your path of מעבדה ברובוטיקה ובקרה של מערכות###
#     pygame.mixer.music.load(ruuner_path)
#     pygame.mixer.music.play()
#     while pygame.mixer.music.get_busy():
#         pygame.time.wait(1000)  # Adjust the delay value (in milliseconds) as needed
#     pygame.quit()